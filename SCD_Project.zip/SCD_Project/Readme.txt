ReportBuilder Project
Overview
ReportBuilder is a Java-based application designed to streamline the creation and management of diverse reports. It empowers users to seamlessly integrate various data visualizations, including pie charts, bar graphs, line graphs, and tables.

Key Features
Component Creation: Users can effortlessly generate Pie Charts, Bar Graphs, Line Graphs, and Tables to enhance their reports.
Structure Persistence: The application supports saving and loading report structures, allowing users to revisit and modify them later.
Export Capabilities: ReportBuilder facilitates the export of reports in PNG or PDF formats for easy sharing and presentation.
Customizable Interface: The application offers a user-friendly interface that can be tailored to meet individual preferences and requirements.
Installation
To run ReportBuilder, ensure that Java is installed on your machine and follow these steps:

Clone the repository or download the source code.
Set up dependencies in your Integrated Development Environment (IDE) or build tool.
Run the main application located in the Interface package.
Usage
Upon launching the application, users can:

Create new report components through the top menu.
Save the current report structure for future reference.
Load previously saved report structures.
Export reports in PNG or PDF formats for external use.
Dependencies
Java Swing for Graphical User Interface (GUI).
JFreeChart for dynamic chart generation (included in the lib directory).
Apache PDFBox for PDF generation (included as pdfbox-3.0.0.jar and related files).