import business.GraphBusiness;
import business.TableBusiness;
import business.TextBusiness;
import dao.GraphDBDAO;
import dao.PieChartDBDAO;
import dao.TableDBDAO;
import dao.TextDBDAO;
import model.Graph;
import model.PieChart;
import model.Table;
import model.Text;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Arrays;
import java.util.List;

public class GUI extends JFrame implements ActionListener {

    private JTextField xAxisLabelField, yAxisLabelField, categoriesField, seriesField, valuesField,componentField,arcAngleField,numRowsField,colNamesField,tableNameField;
    private JButton addGraphButton,addPieChartButton,drawBarGraphButton,drawLineGraphButton,drawGraphButton,drawPieChartButton,drawTableButton ,drawPieChartButtonInside,saveTableButton,drawTextButton, loadAllGraphsButton,loadAllPieChartsButton,addTextButton,loadTextButton,viewTextButton;
    private JTextArea textArea;
    private JTable table;
    private DefaultTableModel model;
    private GraphBusiness graphBusinessForGraphs;
    private GraphBusiness graphBusinessForPieCharts;
    private TableBusiness tableBusiness;
    private TextBusiness textBusiness;
    private List<Graph> graphs;
    private List<PieChart>pieCharts;
    private List<Text>Texts;

    public GUI() {
        setTitle("Graph Panel");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        drawGraphButton = new JButton("Draw Graph");
        drawPieChartButton = new JButton("Draw Pie Chart");
        drawTableButton = new JButton("Draw Table");
        drawTextButton = new JButton("Draw Text");
        loadAllGraphsButton = new JButton("Load all graphs");
        loadAllPieChartsButton = new JButton("Loadd all Pie Charts");
        addGraphButton = new JButton("Add");
        drawBarGraphButton= new JButton("Draw Bar Graph");
        drawLineGraphButton= new JButton("Draw Line Graph");
        addPieChartButton = new JButton("Add");
        drawPieChartButtonInside= new JButton("Draw Pie Chart");
        saveTableButton = new JButton("Save");
        addTextButton = new JButton("Add");
        loadTextButton = new JButton("Load all text");
        viewTextButton = new JButton("View text");
        drawGraphButton.addActionListener(this);
        drawPieChartButton.addActionListener(this);
        drawTableButton.addActionListener(this);
        drawTextButton.addActionListener(this);
        loadAllGraphsButton.addActionListener(this);
        loadAllPieChartsButton.addActionListener(this);
        addGraphButton.addActionListener(this);
        drawBarGraphButton.addActionListener(this);
        drawLineGraphButton.addActionListener(this);
        addPieChartButton.addActionListener(this);
        drawPieChartButtonInside.addActionListener(this);
        saveTableButton.addActionListener(this);
        addTextButton.addActionListener(this);
        loadTextButton.addActionListener(this);
        viewTextButton.addActionListener(this);

        xAxisLabelField = new JTextField(10);
        yAxisLabelField = new JTextField(10);
        categoriesField = new JTextField(10);
        seriesField = new JTextField(10);
        valuesField = new JTextField(10);
        componentField = new JTextField(10);
        arcAngleField = new JTextField(10);
        tableNameField = new JTextField(5);
        numRowsField = new JTextField(5);
        colNamesField= new JTextField( 10);

        panel.add(drawGraphButton);
        panel.add(drawPieChartButton);
        panel.add(drawTableButton);
        panel.add(drawTextButton);
        add(panel);

        table = new JTable(model);
        model = new DefaultTableModel();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == drawGraphButton) {
            setTitle("Graph Creator");
            JPanel inputPanel = new JPanel(new GridLayout(6, 2));
            inputPanel.add(new JLabel("X-axis Label:"));
            inputPanel.add(xAxisLabelField);
            inputPanel.add(new JLabel("Y-axis Label:"));
            inputPanel.add(yAxisLabelField);
            inputPanel.add(new JLabel("Categories:"));
            inputPanel.add(categoriesField);
            inputPanel.add(new JLabel("Series:"));
            inputPanel.add(seriesField);
            inputPanel.add(new JLabel("Values:"));
            inputPanel.add(valuesField);
            JPanel buttonPanel = new JPanel();
            buttonPanel.add(addGraphButton);
            buttonPanel.add(loadAllGraphsButton);
            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.add(inputPanel, BorderLayout.NORTH);
            mainPanel.add(buttonPanel, BorderLayout.CENTER);
            setContentPane(mainPanel);
            pack();
            setLocationRelativeTo(null);
        }
        if (e.getSource() == addGraphButton) {
            try {
                GraphDBDAO graphDBDAO = new GraphDBDAO();
                graphBusinessForGraphs = new GraphBusiness(graphDBDAO);
                String xAxisLabel = xAxisLabelField.getText();
                String yAxisLabel = yAxisLabelField.getText();
                String categories = categoriesField.getText();
                String series = seriesField.getText();
                String value = valuesField.getText();
                Graph graph = new Graph();
                graph.setX_axis_label(xAxisLabel);
                graph.setY_axis_label(yAxisLabel);
                graph.setCategories(categories);
                graph.setSeries(series);
                graph.setValue(value);
                graphBusinessForGraphs.addGraph(graph);
                String[] options = {"Draw Bar Graph", "Draw Line Graph"};
                int choice = JOptionPane.showOptionDialog(
                        this,
                        "Graph added successfully. What type of graph would you like to draw?",
                        "Select Graph Type",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        options,
                        options[0]);
                if (choice == 0) {
                    GraphBusiness.GraphDrawer g1 = new GraphBusiness.GraphDrawer(graph, "bar");
                }
                if (choice == 1) {
                    GraphBusiness.GraphDrawer g2 = new GraphBusiness.GraphDrawer(graph, "line");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid numeric values.");
            }
        }
        if (e.getSource() == loadAllGraphsButton) {
            GraphDBDAO graphDBDAO = new GraphDBDAO();
            graphBusinessForGraphs = new GraphBusiness(graphDBDAO);
            loadGraphs();
            String[] columnNames = {"ID", "Graph No."};
            model = new DefaultTableModel(columnNames, 0);

            for (Graph graph : graphs) {
                Object[] rowData = {graph.getId(), "Graph #" + graph.getId()};
                model.addRow(rowData);
            }

            table.setModel(model); // Set the model to the existing table

            JPanel buttonPanel = new JPanel();
            buttonPanel.add(drawBarGraphButton);
            buttonPanel.add(drawLineGraphButton);

            JFrame tableFrame = new JFrame("Graph Selection");
            tableFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            tableFrame.getContentPane().setLayout(new BorderLayout());
            tableFrame.getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);
            tableFrame.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
            tableFrame.pack();
            tableFrame.setLocationRelativeTo(null);
            tableFrame.setVisible(true);
        }
        if (e.getSource() == drawBarGraphButton || e.getSource() == drawLineGraphButton) {
            int selectedRowIndex = table.getSelectedRow();

            if (selectedRowIndex != -1) {
                int selectedId = (int) table.getValueAt(selectedRowIndex, 0);
                Graph selectedGraph = graphBusinessForGraphs.getGraphById(selectedId);

                if (e.getSource() == drawBarGraphButton) {
                    GraphBusiness.GraphDrawer g1 = new GraphBusiness.GraphDrawer(selectedGraph, "bar");
                } else {
                    GraphBusiness.GraphDrawer g2 = new GraphBusiness.GraphDrawer(selectedGraph, "line");
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please select a row.", "No Row Selected", JOptionPane.WARNING_MESSAGE);
            }
        }


        if (e.getSource() == drawPieChartButton) {
            setTitle("Pie Chart  Creator");
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JPanel inputPanel = new JPanel(new GridLayout(6, 2));
            inputPanel.add(new JLabel("Component Label:"));
            inputPanel.add(componentField);
            inputPanel.add(new JLabel("Arc Angle Label:"));
            inputPanel.add(arcAngleField);
            inputPanel.add(addPieChartButton);
            inputPanel.add(loadAllPieChartsButton);
            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.add(inputPanel, BorderLayout.NORTH);
            setContentPane(mainPanel);
            pack();
            setLocationRelativeTo(null);
        }
        if (e.getSource() == addPieChartButton) {
            try {
                PieChartDBDAO pieChartDBDAO = new PieChartDBDAO();
                graphBusinessForPieCharts = new GraphBusiness(pieChartDBDAO);
                String component = componentField.getText();
                String arcAngle = arcAngleField.getText();
                PieChart pieChart = new PieChart();
                pieChart.setComponent(component);
                pieChart.setArc_angle(arcAngle);
                graphBusinessForPieCharts.addPieChart(pieChart);
                GraphBusiness.GraphDrawer g1 = new GraphBusiness.GraphDrawer(pieChart);
                clearInputFieldsPieCharts();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid numeric values.");
            }
        }
        if (e.getSource() == loadAllPieChartsButton) {
            PieChartDBDAO pieChartDBDAO = new PieChartDBDAO();
            graphBusinessForPieCharts = new GraphBusiness(pieChartDBDAO);
            loadPieCharts();
            String[] columnNames = {"ID", "Graph No."};
            model = new DefaultTableModel(columnNames, 0);
            for (PieChart pieChart : pieCharts) {
                Object[] rowData = {pieChart.getId(), "Graph #" + pieChart.getId()};
                model.addRow(rowData);
            }
            table.setModel(model); // Set the model to the existing table
            JPanel buttonPanel = new JPanel();
            buttonPanel.add(drawPieChartButtonInside);
            JFrame tableFrame = new JFrame("Graph Selection");
            tableFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            tableFrame.getContentPane().setLayout(new BorderLayout());
            tableFrame.getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);
            tableFrame.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
            tableFrame.pack();
            tableFrame.setLocationRelativeTo(null);
            tableFrame.setVisible(true);
        }
        if (e.getSource() == drawPieChartButtonInside) {
            int selectedRowIndex = table.getSelectedRow();
            if (selectedRowIndex != -1) {
                int selectedId = (int) table.getValueAt(selectedRowIndex, 0);
                PieChart selectedPieChart = graphBusinessForPieCharts.getPieChartById(selectedId);
                GraphBusiness.GraphDrawer g1 = new GraphBusiness.GraphDrawer(selectedPieChart);
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please select a row.", "No Row Selected", JOptionPane.WARNING_MESSAGE);
            }
        }


        if (e.getSource() == drawTableButton) {
            setTitle("Draw Table");
            setSize(500, 300);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JPanel inputPanel = new JPanel(new GridLayout(6, 2));
            inputPanel.add(new JLabel("table Name :"));
            inputPanel.add(tableNameField);
            inputPanel.add(new JLabel("Name of Columns:"));
            inputPanel.add(colNamesField);
            inputPanel.add(new JLabel("No of Rows:"));
            inputPanel.add(numRowsField);
            inputPanel.add(saveTableButton);
            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.add(inputPanel, BorderLayout.NORTH);
            mainPanel.add(new JScrollPane(table), BorderLayout.CENTER);
            setContentPane(mainPanel);
            pack();
            setLocationRelativeTo(null);
        }
        if (e.getSource() == saveTableButton) {
            String[] userColNames = colNamesField.getText().split(",");
            String tableName = tableNameField.getText();
            if (userColNames.length > 0) {
                String[] colNames;
                if (!userColNames[0].equalsIgnoreCase("ID")) {
                    colNames = new String[userColNames.length + 1];
                    colNames[0] = "ID";
                    System.arraycopy(userColNames, 0, colNames, 1, userColNames.length);
                } else {
                    colNames = userColNames;
                }

                int numRows = Integer.parseInt(numRowsField.getText());

                // Create a 2D array to store table data
                String[][] tableData = new String[numRows][colNames.length];

                for (int i = 0; i < numRows; i++) {
                    // Prompt the user to enter values for each column
                    for (int j = 0; j < colNames.length; j++) {
                        if (!colNames[j].equalsIgnoreCase("ID")) {
                            String userInput = JOptionPane.showInputDialog("Enter value for " + colNames[j] + " in row " + (i + 1));
                            boolean validInput = false;
                            do {
                                if (userInput != null && !userInput.trim().isEmpty()) {
                                    tableData[i][j] = userInput;
                                    validInput = true;
                                } else {
                                    JOptionPane.showMessageDialog(null, "Please enter a value for " + colNames[j]);
                                }
                            } while (!validInput);
                        } else {
                            // If the column is "ID," set a default value or leave it empty
                            // You can modify this part based on your requirements
                            tableData[i][j] = "";  // Set a default value or leave it empty
                        }
                    }
                }

                Table table = new Table();
                table.setTable_name(tableName);
                table.setColumnNames(colNames);  // Use the modified column names
                table.setTableData(tableData);
                TableDBDAO tableDBDAO = new TableDBDAO(table);
                TableBusiness tableBusiness = new TableBusiness(tableDBDAO);
                tableBusiness.saveTable(table);
                JOptionPane.showMessageDialog(this, "Table loaded: " + tableName, "Table Loaded", JOptionPane.INFORMATION_MESSAGE);

                String[][] makeTable = tableBusiness.loadTable(tableName);

                if (makeTable != null && makeTable.length > 0) {
                    // Create an array to hold column names, including "ID" as the first column
                    String[] allColumnNames = new String[makeTable[0].length + 1];
                    allColumnNames[0] = "ID";

                    // If user provided column names, copy them from index 1 onwards
                    if (userColNames.length > 0) {
                        System.arraycopy(userColNames, 0, allColumnNames, 1, Math.min(userColNames.length, allColumnNames.length - 1));
                    } else {
                        // If no user-provided names, use default names (e.g., "Column1", "Column2", ...)
                        for (int i = 1; i < allColumnNames.length; i++) {
                            allColumnNames[i] = "Column" + i;
                        }
                    }
                    if (allColumnNames != null) {
                        model.setDataVector(makeTable, allColumnNames);
                        JTable loadedTable = new JTable(makeTable, allColumnNames);
                        JScrollPane scrollPane = new JScrollPane(loadedTable);
                        setLayout(new BorderLayout());
                        add(scrollPane, BorderLayout.CENTER);
                        pack();
                        setLocationRelativeTo(null); // Center the frame on the screen
                        setVisible(true);
                        JOptionPane.showMessageDialog(null, scrollPane, "Table Display", JOptionPane.PLAIN_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "No data to display.", "Empty Table", JOptionPane.INFORMATION_MESSAGE);

                    }
                }
            }
        }


        if(e.getSource() ==  drawTextButton) {
            setTitle("Text Creator");
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            addTextButton = new JButton("Add Text");
            loadTextButton = new JButton("Load Text");
            addTextButton.setPreferredSize(new Dimension(100, 30));
            loadTextButton.setPreferredSize(new Dimension(100, 30));
            JPanel mainPanel = new JPanel(new BorderLayout());
            JLabel label = new JLabel("Write text here:");
            textArea = new JTextArea();
            textArea.setRows(10);
            mainPanel.add(label, BorderLayout.NORTH);
            mainPanel.add(new JScrollPane(textArea), BorderLayout.CENTER);
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
            buttonPanel.add(addTextButton);
            buttonPanel.add(loadTextButton);
            mainPanel.add(buttonPanel, BorderLayout.SOUTH);
            addTextButton.addActionListener(this);
            loadTextButton.addActionListener(this);
            setContentPane(mainPanel);
            pack();
            setLocationRelativeTo(null);
        }
        if(e.getSource() == addTextButton ){
            try {
                TextDBDAO textDBDAO = new TextDBDAO();
                textBusiness = new TextBusiness(textDBDAO);
                String text = textArea.getText();
                Text Text = new Text();
                Text.setText(text);
                textBusiness.addText(Text);
                clearInputFieldsText();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid numeric values.");
        }
        }
        if(e.getSource() == loadTextButton){
            TextDBDAO textDBDAO = new TextDBDAO();
            textBusiness= new TextBusiness(textDBDAO);
            loadTexts();
            String[] columnNames = {"ID", " Text No."};
            model = new DefaultTableModel(columnNames, 0);
            for (Text Text : Texts) {
                Object[] rowData = {Text.getId(), "Graph #" + Text.getId()};
                model.addRow(rowData);
            }
            table.setModel(model); // Set the model to the existing table
            JPanel panel = new JPanel(new BorderLayout());
            panel.add(new JScrollPane(table), BorderLayout.CENTER);
            panel.add(viewTextButton, BorderLayout.SOUTH);
            this.setContentPane(panel);
            this.pack();
            this.setLocationRelativeTo(null);
        }
        if(e.getSource()==viewTextButton){
            TextDBDAO textDBDAO = new TextDBDAO();
            textBusiness= new TextBusiness(textDBDAO);
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int selectedId = (int) table.getValueAt(selectedRow, 0); // Assuming ID is in the first column
                Text Text =textBusiness.getTextById(selectedId); // Replace with your actual method to fetch text by ID

                JOptionPane.showMessageDialog(null, Text.getText(), "View Text", JOptionPane.PLAIN_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Please select a row first.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void loadPieCharts() {
        PieChartDBDAO pieChartDBDAO = new PieChartDBDAO();
        graphBusinessForPieCharts = new GraphBusiness(pieChartDBDAO);
        pieCharts = graphBusinessForPieCharts.loadPieChart();
        refreshTablePieChart();
    }

    private void refreshTablePieChart() {
        model.setRowCount(0);
        for (PieChart pieChart : pieCharts) {
            model.addRow(new Object[]{pieChart.getId(), pieChart. getComponent(), pieChart.getArc_angle()});
        }
    }

    private void clearInputFieldsPieCharts() {
        componentField.setText("");
        arcAngleField.setText("");
    }

    private void clearInputFieldsText(){
        textArea.setText("");
    }

    private void loadTexts() {
        Texts =textBusiness.loadText();
        refreshTableText();
    }

    private void refreshTableText() {
        model.setRowCount(0);
        for (Text Text : Texts) {
            model.addRow(new Object[]{Text.getId(), Text.getText()});
        }
    }

    private void loadGraphs() {
        graphs = graphBusinessForGraphs.loadGraph();
        refreshTableGraph();
    }

    private void refreshTableGraph() {
        model.setRowCount(0);
        for (Graph graph : graphs) {
            model.addRow(new Object[]{graph.getId(), graph. getX_axis_label(), graph.getY_axis_label(),
                    graph.getCategories(), graph.getSeries(), graph.getValue()});
        }
    }

    private void clearInputFieldsGraphs() {
        xAxisLabelField.setText("");
        yAxisLabelField.setText("");
        categoriesField.setText("");
        seriesField.setText("");
        valuesField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GUI().setVisible(true));
    }
}

