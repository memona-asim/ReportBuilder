import business.GraphBusiness;
import business.TableBusiness;
import dao.GraphDBDAO;
import dao.PieChartDBDAO;
import dao.TableDBDAO;
import model.Graph;
import model.PieChart;
import model.Table;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;

public class GUI extends JFrame implements ActionListener {

    private JTextField xAxisLabelField, yAxisLabelField, categoriesField, seriesField, valuesField,componentField,arcAngleField,numRowsField,colNamesField,tableNameField;
    private JButton addGraphButton,addPieChartButton,drawBarGraphButton,drawLineGraphButton,drawGraphButton,drawPieChartButton,drawTableButton ,drawPieChartButtonInside,saveTableButton ;
    private JTable table;
    private DefaultTableModel model;
    private GraphBusiness graphBusinessForGraphs;
    private GraphBusiness graphBusinessForPieCharts;
    private TableBusiness tableBusiness;
    private List<Graph> graphs;
    private List<PieChart>pieCharts;

    public GUI() {
        setTitle("Graph Panel");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        drawGraphButton = new JButton("Draw Graph");
        drawPieChartButton = new JButton("Draw Pie Chart");
        drawTableButton = new JButton("Draw Table");
        drawGraphButton.addActionListener(this);
        drawPieChartButton.addActionListener(this);
        drawTableButton.addActionListener(this);
        panel.add(drawGraphButton);
        panel.add(drawPieChartButton);
        panel.add(drawTableButton);
        add(panel);


        xAxisLabelField = new JTextField(10);
        yAxisLabelField = new JTextField(10);
        categoriesField = new JTextField(10);
        seriesField = new JTextField(10);
        valuesField = new JTextField(10);
        // Button
        addGraphButton = new JButton("Add");
        addGraphButton.addActionListener(this);
        drawBarGraphButton= new JButton("Draw Bar Graph");
        drawBarGraphButton.addActionListener(this);
        drawLineGraphButton= new JButton("Draw Line Graph");
        drawLineGraphButton.addActionListener(this);
        // Text fields
        componentField = new JTextField(10);
        arcAngleField = new JTextField(10);
        // Button
        addPieChartButton = new JButton("Add");
        addPieChartButton.addActionListener(this);
        drawPieChartButtonInside= new JButton("Draw Pie Chart");
        drawPieChartButtonInside.addActionListener(this);
        // Text Fields
        tableNameField = new JTextField(5);
        numRowsField = new JTextField(5);
        colNamesField= new JTextField( 10);
        // Button
        saveTableButton = new JButton("Save");
        saveTableButton.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource() == drawGraphButton )
        {
            GraphDBDAO GraphDBDAO = new GraphDBDAO();
            graphBusinessForGraphs = new GraphBusiness(GraphDBDAO);
            setTitle("Graph Creator");
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            // Table setup
            String[] columnNames = {"ID", "X-axis Label", "Y-axis Label", "Categories", "Series", "Values"};
            model = new DefaultTableModel(columnNames, 0);
            table = new JTable(model);
            // Add components to the frame
            JPanel inputPanel = new JPanel(new GridLayout(6, 2));
            inputPanel.add(new JLabel("X-axis Label:"));
            inputPanel.add(xAxisLabelField);
            inputPanel.add(new JLabel("Y-axis Label:"));
            inputPanel.add(yAxisLabelField);
            inputPanel.add(new JLabel("Categories:"));
            inputPanel.add(categoriesField);
            inputPanel.add(new JLabel("Series:"));
            inputPanel.add(seriesField);
            inputPanel.add(new JLabel("Values:"));
            inputPanel.add(valuesField);
            inputPanel.add(addGraphButton);
            inputPanel.add(drawBarGraphButton);
            inputPanel.add(drawLineGraphButton);
            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.add(inputPanel, BorderLayout.NORTH);
            mainPanel.add(new JScrollPane(table), BorderLayout.CENTER);
            setContentPane(mainPanel);
            pack();
            setLocationRelativeTo(null);
            // Load existing  graphs from the database
            loadGraphs();
        }
        // add Graphs
        if (e.getSource() == addGraphButton) {
            try {
                String xAxisLabel = xAxisLabelField.getText();
                String yAxisLabel = yAxisLabelField.getText();
                String categories = categoriesField.getText();
                String series = seriesField.getText();
                String value  = valuesField.getText();
                Graph graph=new Graph();
                graph.setX_axis_label(xAxisLabel);
                graph.setY_axis_label(yAxisLabel);
                graph.setCategories(categories);
                graph.setSeries(series);
                graph.setValue(value);
                graphBusinessForGraphs.addGraph(graph);
                loadGraphs();
                clearInputFieldsGraphs();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid numeric values.");
            }
        }
           // draw bargarph
        if (e.getSource() == drawBarGraphButton) {
            int selectedRowIndex = table.getSelectedRow();
            if (selectedRowIndex != -1) {
                int selectedId = (int) table.getValueAt(selectedRowIndex, 0);
                Graph selectedGraph = graphBusinessForGraphs.getGraphById(selectedId);
                GraphBusiness.GraphDrawer g1=new GraphBusiness.GraphDrawer(selectedGraph,"bar");
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please select a row.", "No Row Selected", JOptionPane.WARNING_MESSAGE);
            }
        }
            // draw line graph
        if (e.getSource() == drawLineGraphButton) {

            int selectedRowIndex = table.getSelectedRow();
            if (selectedRowIndex != -1) {
                int selectedId = (int) table.getValueAt(selectedRowIndex, 0);
                Graph selectedGraph = graphBusinessForGraphs.getGraphById(selectedId);
                GraphBusiness.GraphDrawer g2=new GraphBusiness.GraphDrawer(selectedGraph,"line");
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please select a row.", "No Row Selected", JOptionPane.WARNING_MESSAGE);
            }
        }


        if(e.getSource() == drawPieChartButton )
        {
            PieChartDBDAO pieChartDBDAO = new PieChartDBDAO();
            graphBusinessForPieCharts = new GraphBusiness(pieChartDBDAO);
            setTitle("Pie Chart  Creator");
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            // Table setup
            String[] columnNames = {"ID", "Component", "Arc Angle"};
            model = new DefaultTableModel(columnNames, 0);
            table = new JTable(model);
            // Add components to the frame
            JPanel inputPanel = new JPanel(new GridLayout(6, 2));
            inputPanel.add(new JLabel("Component Label:"));
            inputPanel.add(componentField);
            inputPanel.add(new JLabel("Arc Angle Label:"));
            inputPanel.add(arcAngleField);
            inputPanel.add(addPieChartButton);
            inputPanel.add(drawPieChartButtonInside);
            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.add(inputPanel, BorderLayout.NORTH);
            mainPanel.add(new JScrollPane(table), BorderLayout.CENTER);
            setContentPane(mainPanel);
            pack();
            setLocationRelativeTo(null);
            loadPieCharts();
        }
        // add Pie Chart
        if (e.getSource() == addPieChartButton) {
            try {
                String component = componentField.getText();
                String arcAngle = arcAngleField.getText();
                PieChart pieChart = new PieChart();
                pieChart.setComponent(component);
                pieChart.setArc_angle(arcAngle);
                graphBusinessForPieCharts. addPieChart(pieChart);
                loadPieCharts();
                clearInputFieldsPieCharts();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid numeric values.");
            }
        }
        // draw pieChart
        if (e.getSource() == drawPieChartButtonInside) {
            int selectedRowIndex = table.getSelectedRow();
            if (selectedRowIndex != -1) {
                int selectedId = (int) table.getValueAt(selectedRowIndex, 0);
                PieChart selectedPieChart= graphBusinessForPieCharts.getPieChartById(selectedId);
                GraphBusiness.GraphDrawer g1=new GraphBusiness.GraphDrawer(selectedPieChart);
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please select a row.", "No Row Selected", JOptionPane.WARNING_MESSAGE);
            }
        }


        if(e.getSource()==drawTableButton){
            setTitle("Draw Table");
            setSize(500, 300);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JPanel inputPanel = new JPanel(new GridLayout(6, 2));
            inputPanel.add(new JLabel("table Name :"));
            inputPanel.add(tableNameField);
            inputPanel.add(new JLabel("Name of Columns:"));
            inputPanel.add(colNamesField);
            inputPanel.add(new JLabel("No of Rows:"));
            inputPanel.add(numRowsField);
            inputPanel.add(saveTableButton);
            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.add(inputPanel, BorderLayout.NORTH);
            mainPanel.add(new JScrollPane(table), BorderLayout.CENTER);
            setContentPane(mainPanel);
            pack();
            setLocationRelativeTo(null);
        }
        // Save Table
        if(e.getSource()==saveTableButton){
            String[] userColNames = colNamesField.getText().split(",");
            String tableName =tableNameField.getText();
            if (userColNames.length > 0) {
                String[] colNames;
                if (!userColNames[0].equalsIgnoreCase("ID")) {
                    colNames = new String[userColNames.length + 1];
                    colNames[0] = "ID";
                    System.arraycopy(userColNames, 0, colNames, 1, userColNames.length);
                } else {
                    // If the first column is already "ID," use the user-provided names
                    colNames = userColNames;
                }

                int numRows = Integer.parseInt(numRowsField.getText());

                // Create a 2D array to store table data
                String[][] tableData = new String[numRows][colNames.length];

                for (int i = 0; i < numRows; i++) {
                    // Prompt the user to enter values for each column
                    for (int j = 0; j < colNames.length; j++) {
                        String userInput = JOptionPane.showInputDialog("Enter value for " + colNames[j] + " in row " + (i + 1));
                        boolean validInput = false;
                        do {
                            if (userInput != null && !userInput.trim().isEmpty()) {
                                tableData[i][j] = userInput;
                                validInput = true;
                            } else {
                                JOptionPane.showMessageDialog(null, "Please enter a value for " + colNames[j]);
                            }
                        } while (!validInput);
                    }
                }

                Table table=new Table();
                table.setTable_name(tableName);
                table.setColumnNames(userColNames);
                table.setTableData(tableData);
                TableDBDAO tableDBDAO= new TableDBDAO(table);
                TableBusiness tableBusniess= new TableBusiness(tableDBDAO);
                tableBusniess.saveTable(table);
                JOptionPane.showMessageDialog(this, "Table loaded: " + tableName, "Table Loaded", JOptionPane.INFORMATION_MESSAGE);

                String[][] makeTable = tableBusiness.loadTable(tableName);
                String[] columnNames = userColNames;  // Replace with the actual column names

// Create a new JTable with the loaded data
                JTable loadedTable = new JTable(makeTable, columnNames);

// Put the JTable inside a JScrollPane
                JScrollPane scrollPane = new JScrollPane(loadedTable);

// Set layout and add components to the frame
                setLayout(new BorderLayout());
                add(scrollPane, BorderLayout.CENTER);
                pack();
                setLocationRelativeTo(null); // Center the frame on the screen
                setVisible(true);

// Show a JOptionPane with the table
                JOptionPane.showMessageDialog(null, scrollPane, "Table Display", JOptionPane.PLAIN_MESSAGE);
            }
        }







//        if(e.getSource() == selectImageButton ) {
//            setTitle("Image Database GUI");
//            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//            setSize(600, 400);
//            // Table
//            String[] columnNames = {"ID", "Name", "Path"};
//            model = new DefaultTableModel(columnNames, 0);
//            table = new JTable(model);
//            // Panel setup
//            JPanel inputPanel = new JPanel(new GridLayout(3, 2));
//            inputPanel.add(new JLabel("Image Name:"));
//            inputPanel.add(imageNameField);
//            inputPanel.add(new JLabel("Choose File:"));
//            inputPanel.add(chooseFileButton);
//            inputPanel.add(new JLabel("Add File:"));
//            inputPanel.add(addFileButton);
//            JPanel mainPanel = new JPanel(new BorderLayout());
//            mainPanel.add(inputPanel, BorderLayout.NORTH);
//            mainPanel.add(new JScrollPane(table), BorderLayout.CENTER);
//            setContentPane(mainPanel);
//            pack();
//            setLocationRelativeTo(null);
//        }

    }
//
//
//
//    public Icon ResizeImage(String imagePath) {
//        ImageIcon MyImage = new ImageIcon(imagePath);
//        Image img = MyImage.getImage();
//        Image newImg = img.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
//        return new ImageIcon(newImg);
//    }

    private void loadPieCharts() {
        pieCharts = graphBusinessForPieCharts.loadPieChart();
        refreshTablePieChart();
    }

    private void refreshTablePieChart() {
        model.setRowCount(0);
        for (PieChart pieChart : pieCharts) {
            model.addRow(new Object[]{pieChart.getId(), pieChart. getComponent(), pieChart.getArc_angle()});
        }
    }

    private void clearInputFieldsPieCharts() {
        componentField.setText("");
        arcAngleField.setText("");
    }

    private void loadGraphs() {
        graphs = graphBusinessForGraphs.loadGraph();
        refreshTableGraph();
    }

    private void refreshTableGraph() {
        model.setRowCount(0);
        for (Graph graph : graphs) {
            model.addRow(new Object[]{graph.getId(), graph. getX_axis_label(), graph.getY_axis_label(),
                    graph.getCategories(), graph.getSeries(), graph.getValue()});
        }
    }

    private void clearInputFieldsGraphs() {
        xAxisLabelField.setText("");
        yAxisLabelField.setText("");
        categoriesField.setText("");
        seriesField.setText("");
        valuesField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GUI().setVisible(true));
    }
}
