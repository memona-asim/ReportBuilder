package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import business.BusinessOtherGraph;
import business.BusinessPieGraph;
import dao.BarGraphDBDAO;
import model.OtherGraph;
import model.PieGraph;


public class GUI extends JFrame implements ActionListener {

    private JTextField xField, yField,componentField,arcAngleField;
    private JButton addOtherGraph,addPieChart, createPieChartButton, createOtherGraphButton;
    private JTable table1,table2;
    private DefaultTableModel model1,model2;
    private BusinessOtherGraph businessOtherGraph;
    private BusinessPieGraph businessPieGraph;
    List<OtherGraph> dimensionsOtherGraph;
    List<PieGraph>   dimensionPieGraph;

    public GUI() {
        BarGraphDBDAO modeldao = new BarGraphDBDAO();
        daoLayer.PieGraphDAO modeldao2 = new daoLayer.PieGraphDAO(); // Create an instance of ModelDAO
        businessOtherGraph = new BusinessOtherGraph(modeldao);
        businessPieGraph = new BusinessPieGraph(modeldao2);// Pass ModelDAO to Business constructor
        gui();
    }

    public void gui() {

        setTitle("Main Screen");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        createPieChartButton = new JButton("Create Pie Chart");
        createPieChartButton.addActionListener(this);

        createOtherGraphButton = new JButton("Create Other Graph");
        createOtherGraphButton.addActionListener(this);

        JPanel mainPanel = new JPanel(new GridLayout(2, 1));
        mainPanel.add(createPieChartButton);
        mainPanel.add(createOtherGraphButton);

        setContentPane(mainPanel);
        pack();
        setLocationRelativeTo(null);

    }

    @Override
    public void actionPerformed(ActionEvent e) {


        if (e.getSource() == createPieChartButton) {

            setTitle("Pie Chart");
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            componentField= new JTextField(10);
            arcAngleField = new JTextField(10);

            String[] columnNames = {"S.No", "component", "arcAngleField"};
            model1 = new DefaultTableModel(columnNames, 0);

            JPanel inputPanel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.insets = new Insets(5, 5, 5, 5); // Padding
            inputPanel.add(new JLabel("component:"), gbc);

            gbc.gridx = 1;
            inputPanel.add(componentField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 1;
            inputPanel.add(new JLabel("arc angle:"), gbc);

            gbc.gridx = 1;
            inputPanel.add(arcAngleField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.gridwidth = 2;
            addPieChart = new JButton("Add Data");
            addPieChart.addActionListener(this);
            inputPanel.add(addPieChart, gbc);

            table1 = new JTable(model1);
            JScrollPane scrollPane = new JScrollPane(table1);

            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.add(inputPanel, BorderLayout.NORTH);
            mainPanel.add(scrollPane, BorderLayout.CENTER);

            setContentPane(mainPanel);
            pack();
            setLocationRelativeTo(null);
            pieGraphRefreshTable();

        }

        else if (e.getSource() == createOtherGraphButton) {

            setTitle("Other Graph");
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            xField = new JTextField(10);
            yField = new JTextField(10);

            String[] columnNames = {"S.No", "x-coordinate", "y-coordinate"};
            model2 = new DefaultTableModel(columnNames, 0);

            JPanel inputPanel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.insets = new Insets(5, 5, 5, 5); // Padding
            inputPanel.add(new JLabel("x-coordinate:"), gbc);

            gbc.gridx = 1;
            inputPanel.add(xField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 1;
            inputPanel.add(new JLabel("y-coordinate:"), gbc);

            gbc.gridx = 1;
            inputPanel.add(yField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.gridwidth = 2;
            addOtherGraph = new JButton("Add Data");
            addOtherGraph.addActionListener(this);
            inputPanel.add(addOtherGraph, gbc);

            table2 = new JTable(model2);
            JScrollPane scrollPane = new JScrollPane(table2);

            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.add(inputPanel, BorderLayout.NORTH);
            mainPanel.add(scrollPane, BorderLayout.CENTER);

            setContentPane(mainPanel);
            pack();
            setLocationRelativeTo(null);
            otherGraphRefreshTable();

        }

        else if (e.getSource() == addOtherGraph) {
            try {
                float x = Float.parseFloat(xField.getText());
                float y = Float.parseFloat(yField.getText());
                OtherGraph m = new OtherGraph(x, y);
                businessOtherGraph.addDimension(m);
                otherGraphRefreshTable();
                xField.setText("");
                yField.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid numeric values for x and y.");
            }
        }

        else if (e.getSource() == addPieChart) {
            try {
                float x = Float.parseFloat(componentField.getText());
                float y = Float.parseFloat(arcAngleField.getText());
                PieGraph m = new PieGraph(x, y);
                businessPieGraph.addDimension(m);
                pieGraphRefreshTable();
                componentField.setText("");
                arcAngleField.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid numeric values for x and y.");
            }
        }
    }

    private void otherGraphRefreshTable() {
        model2.setRowCount(0);
        dimensionsOtherGraph =businessOtherGraph.getAllDimensions();
        for (OtherGraph d : dimensionsOtherGraph) {
            model2.addRow(new Object[]{d.getId(), d.getXCoordinate(), d.getYCoordinate()});
        }
    }

    private void pieGraphRefreshTable() {
        model1.setRowCount(0);
        dimensionPieGraph =businessPieGraph.getAllDimensions();
        for (PieGraph d : dimensionPieGraph) {
            model1.addRow(new Object[]{d.getId(), d.getComponent(), d.getArcAngle()});
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new GUI().setVisible(true);
            BarGraphDBDAO.clearTable();
            daoLayer.PieGraphDAO.clearTable();
        });
    }
}
