package business;

import dao.GraphDBDAO;
//import jdk.internal.loader.Resource;
import dao.PieChartDBDAO;
import model.Graph;
import model.PieChart;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class GraphBusiness {
    private GraphDBDAO graphDBDAO;
    private PieChartDBDAO pieChartDBDAO;

    public GraphBusiness(GraphDBDAO graphDBDAO) {
        this.graphDBDAO = graphDBDAO;
    }

    public GraphBusiness(PieChartDBDAO pieChartDBDAO) {
        this.pieChartDBDAO = pieChartDBDAO;
    }

    public void addGraph(Graph graph) {
        graphDBDAO.addGraph(graph);

    }
    public void addPieChart(PieChart pieChart) {
            pieChartDBDAO.addPieChart(pieChart);

    }

    public List<Graph> loadGraph() {
        List<Graph> graphs = graphDBDAO.loadGraph();
        return graphs;
    }

    public List<PieChart> loadPieChart() {
        List<PieChart> pieCharts = pieChartDBDAO.loadPieChart();
        return pieCharts;
    }

    public Graph getGraphById(int Id) {
        return graphDBDAO.getGraphById(Id);
    }

    public PieChart getPieChartById(int Id) {
        return pieChartDBDAO.getPieChartById(Id);
    }


    private List<String> stringToList(String inputString) {
        String[] stringArray = inputString.split(",");
        return List.of(stringArray);
    }

    private List<Float> stringToFloatList(String inputString) {
        String[] stringArray = inputString.split(",");
        Float[] floatArray = new Float[stringArray.length];
        for (int i = 0; i < stringArray.length; i++) {
            floatArray[i] = Float.parseFloat(stringArray[i]);
        }
        return List.of(floatArray);
    }

//    public boolean validateInputs(Graph graph) {
//
//        if (isEmpty(graph.getX_axis_label()) || isEmpty(graph.getY_axis_label()) ||
//                isEmpty(graph.getCategories()) || isEmpty(graph.getSeries()) || isEmpty(graph.getValue())) {
//            return false; // Any field is empty
//        }
//
//        // Parse the strings into lists
//        List<String> categories = Arrays.asList(graph.getCategories().split(","));
//        List<String> seriesList = Arrays.asList(graph.getSeries().split(","));
//        List<Float> values = Arrays.stream(graph.getValue().split(","))
//                .map(Float::parseFloat)
//                .collect(Collectors.toList());
//
//        int totalSeries = seriesList.size();
//        int totalCategories = categories.size();
//
//       // Check if the number of series is the same for all categories
//        for (int i = 1; i < totalCategories; i++) {
//            if (seriesList.size() != totalSeries) {
//                return false; // Mismatch in the number of series
//            }
//        }
//
//         // Check if the sum of series in all categories is equal to the size of values
//        int totalSeriesInAllCategories = totalSeries * totalCategories;
//        if (totalSeriesInAllCategories != values.size()) {
//            return false; // Mismatch in the size of values
//        }
//        // All checks passed
//        return true;
//    }


//    public boolean validateInputs(PieChart pieChart) {
//        if (isEmpty(pieChart.getComponent()) || isEmpty(pieChart.getArc_angle()) || (pieChart.getComponent().length() != pieChart.getArc_angle().length())) {
//            return false;
//        }
//        return true;
//    }

    private boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

    public static class GraphDrawer extends JFrame {
        private Graph graph;
        private String chartType;
        private PieChart pieChart;

        public GraphDrawer(PieChart pieChart) {
            this.pieChart = pieChart;
            setTitle("Pie Chart");
            JFreeChart chart = createPieChart();
            ChartPanel chartPanel = new ChartPanel(chart);
            chartPanel.setPreferredSize(new Dimension(560, 370));
            setContentPane(chartPanel);
            pack();
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
            setVisible(true);
        }

        public GraphDrawer(Graph graph, String chartType) {
            this.graph = graph;
            this.chartType = chartType;
            setTitle("Graph Drawer");
            JFreeChart chart = createChart();
            ChartPanel chartPanel = new ChartPanel(chart);
            chartPanel.setPreferredSize(new Dimension(560, 370));
            setContentPane(chartPanel);
            pack();
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
            setVisible(true);
        }

        private JFreeChart createChart() {
            if (chartType.equalsIgnoreCase("bar")) {
                return createBarChart();
            } else if (chartType.equalsIgnoreCase("line")) {
                return createLineChart();
            } else {
                throw new IllegalArgumentException("Invalid chart type: " + chartType);
            }
        }

        private JFreeChart createBarChart() {
            List<String> categories = Arrays.asList(graph.getCategories().split(","));
            List<String> seriesList = Arrays.asList(graph.getSeries().split(","));
            List<Float> values = Arrays.stream(graph.getValue().split(","))
                    .map(Float::parseFloat)
                    .collect(Collectors.toList());

            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
            for (int i = 0; i < categories.size(); i++) {
                for (int j = 0; j < seriesList.size(); j++) {
                    dataset.addValue(values.get(i * seriesList.size() + j), seriesList.get(j), categories.get(i));
                }
            }

            return ChartFactory.createBarChart(
                    graph.getX_axis_label(),
                    graph.getY_axis_label(),
                    "Value",
                    dataset,
                    PlotOrientation.VERTICAL,
                    true,
                    true,
                    false
            );
        }

        private JFreeChart createLineChart() {
            List<String> categories = Arrays.asList(graph.getCategories().split(","));
            List<String> seriesList = Arrays.asList(graph.getSeries().split(","));
            List<Float> values = Arrays.stream(graph.getValue().split(","))
                    .map(Float::parseFloat)
                    .collect(Collectors.toList());

            XYSeriesCollection dataset = new XYSeriesCollection();
            for (int i = 0; i < seriesList.size(); i++) {
                XYSeries series = new XYSeries(seriesList.get(i));
                for (int j = 0; j < categories.size(); j++) {
                    series.add(j, values.get(i * categories.size() + j));
                }
                dataset.addSeries(series);
            }

            JFreeChart chart = ChartFactory.createXYLineChart(
                    graph.getX_axis_label(),
                    graph.getY_axis_label(),
                    "Value",
                    dataset,
                    PlotOrientation.VERTICAL,
                    true,
                    true,
                    false
            );

            XYPlot plot = chart.getXYPlot();
            plot.setDomainPannable(true);
            plot.setRangePannable(true);

            return chart;
        }

        public JFreeChart createPieChart() {
            List<String> components = Arrays.asList(pieChart.getComponent().split(","));
            List<Float> arcAngles = Arrays.stream(pieChart.getArc_angle().split(","))
                    .map(Float::parseFloat)
                    .collect(Collectors.toList());

            DefaultPieDataset dataset = new DefaultPieDataset();
            for (int i = 0; i < components.size(); i++) {
                dataset.setValue(components.get(i), arcAngles.get(i));
            }

            return ChartFactory.createPieChart(
                    pieChart.getComponent(),
                    dataset,
                    true,
                    true,
                    false
            );
        }
    }
}

