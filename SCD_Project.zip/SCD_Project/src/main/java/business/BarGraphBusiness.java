package business;

import dao.BarGraphDBDAO;
import jdk.internal.loader.Resource;
import model.BarGraph;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class BarGraphBusiness{
    private BarGraphDBDAO barGraphDBDAO;

    public void BarGraphBusiness(BarGraphDBDAO barGraphDBDAO){this.barGraphDBDAO=barGraphDBDAO;}

    public void addBarGraph(BarGraph barGraph) { barGraphDBDAO.addBarGraph(barGraph);}

    public List<BarGraph> loadBarGraph(){ List<BarGraph> barGraphs= barGraphDBDAO.loadBarGraph(); return barGraphs;}

    public BarGraph getBarGraphById(int Id) { return barGraphDBDAO.getBarGraphById( Id);}

    public void drawBarGraph(BarGraph barGraph){

        String x_axis_label= barGraph.getX_axis_label();
        String y_axis_label=barGraph.getY_axis_label();
        String categoriesString=barGraph.getCategories();
        String seriesString=barGraph.getSeries();
        String valueString=barGraph.getValue();

    }

}
