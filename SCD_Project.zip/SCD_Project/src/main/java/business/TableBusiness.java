package business;

import dao.GraphDBDAO;
import dao.TableDBDAO;
import model.Table;

import javax.swing.table.DefaultTableModel;

public class TableBusiness {
    private TableDBDAO tableDBDAO;

    public TableBusiness(TableDBDAO tableDBDAO) {
        this.tableDBDAO = tableDBDAO;
    }

    public void saveTable(Table table) {tableDBDAO.saveTable(table);}
    public String[][] loadTable(String name ){String[][]  tableData = tableDBDAO.loadTable(name); return tableData;}

}
