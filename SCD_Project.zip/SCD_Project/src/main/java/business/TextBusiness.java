package business;

import dao.TextDBDAO;
import model.Text;

import java.util.List;

public class TextBusiness {
    private TextDBDAO textDBDAO;

    public TextBusiness(TextDBDAO textDBDAO) {this.textDBDAO = textDBDAO;}

    public void addText(Text Text){ textDBDAO.addText(Text);}

    public List<Text> loadText(){List<Text> Texts=textDBDAO.loadText(); return Texts;}

    public Text getTextById(int id){Text Text =textDBDAO.getTextById(id); return Text;}

}
