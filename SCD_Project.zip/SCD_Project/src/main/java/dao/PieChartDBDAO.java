package dao;

import model.Graph;
import model.PieChart;

import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class PieChartDBDAO {

    public void addPieChart(PieChart pieChart) {
        PreparedStatement statement = null;
        try (Connection connection = DatabaseConfig.getConnection()) {
            statement = connection.prepareStatement(
                    "INSERT INTO PieChartTable (component,arc_angle) VALUES (?,?)",
                    Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, pieChart.getComponent());
            statement.setString(2, pieChart. getArc_angle());

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating a  pie Chart failed, no rows affected.");
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int Id = generatedKeys.getInt(1);
                    pieChart.setId(Id);
                } else {
                    throw new SQLException("Creating Pie Chart failed, no ID obtained.");
                }
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    // Handle or log the exception
                }
            }
        }
    }


    public List<PieChart> loadPieChart() {
        List<PieChart> pieCharts = new ArrayList<>();

        try (Connection connection = DatabaseConfig.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM PieChartTable")) {

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String component = resultSet.getString("component");
                String arc_angle = resultSet.getString("arc_angle");
                PieChart pieChart = new PieChart(id, component, arc_angle);
                pieCharts.add(pieChart);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error retrieving all Pie Charts from the database");
        }
        return pieCharts;
    }


    public PieChart getPieChartById(int Id) {
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM PieChartTable WHERE id = ?")) {
            statement.setInt(1, Id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String component = resultSet.getString("component");
                    String arc_angle = resultSet.getString("arc_angle");
                    PieChart piechart= new PieChart(Id,component,arc_angle);
                    return piechart;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception in a more appropriate way in a real application
            throw new RuntimeException("Error retrieving  pie chart  by id  from the database");
        }
        return null;
    }


    public static List<String> StringToList(String string) {
        String[] stringArray = string.split(",");
        return Arrays.asList(stringArray);
    }
}
