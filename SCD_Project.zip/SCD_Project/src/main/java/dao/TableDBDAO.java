package dao;

import model.Graph;
import model.Table;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class TableDBDAO {
    private Table table;

    public TableDBDAO(Table table){
        this.table=table;
    }

    public void saveTable(Table table) {
        String tableName = table.getTable_name();
        String[] columnNames = table.getColumnNames();
        String[][] tableData = table.getTableData();

        String insertRowQuery = "INSERT INTO " + tableName + " (";
        for (int i = 0; i < columnNames.length; i++) {
            insertRowQuery += columnNames[i];
            if (i < columnNames.length - 1) {
                insertRowQuery += ", ";
            }
        }
        insertRowQuery += ") VALUES (";

        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement insertRowStatement = connection.prepareStatement(insertRowQuery)) {

            for (int row = 0; row < tableData.length; row++) {
                for (int col = 0; col < columnNames.length; col++) {
                    String value = tableData[row][col];
                    insertRowStatement.setString(col + 1, value);
                }
                insertRowStatement.executeUpdate();
            }

            JOptionPane.showMessageDialog(null, "Table saved successfully!");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public String[][] loadTable(String name) {
        List<String[]> loadedData = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + name;

        try (Connection connection = DatabaseConfig.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectQuery)) {

            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            while (resultSet.next()) {
                String[] rowData = new String[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    rowData[i - 1] = resultSet.getString(i);
                }
                loadedData.add(rowData);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error loading table from database: " + e.getMessage(), e);
        }

        return loadedData.toArray(new String[0][0]);
    }




}
