package dao;

//import com.sun.tools.jdeps.Graph;
//mport jdk.internal.loader.Resource;
import model.Graph;

import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GraphDBDAO {

    public void addGraph(Graph graph) {
        PreparedStatement statement = null;
        try (Connection connection = DatabaseConfig.getConnection()) {
            statement = connection.prepareStatement(
                    "INSERT INTO BarGraphTable (x_axis_label,y_axis_label,categories,series,value) VALUES (?,?,?,?,?)",
                    Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, graph.getX_axis_label());
            statement.setString(2, graph.getY_axis_label());
            statement.setString(3, graph.getCategories());
            statement.setString(4, graph.getSeries() );
            statement.setString(5, graph.getValue());

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating a Graph failed, no rows affected.");
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int Id = generatedKeys.getInt(1);
                    graph.setId(Id);
                } else {
                    throw new SQLException("Creating Graph failed, no ID obtained.");
                }
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    // Handle or log the exception
                }
            }
        }
    }

    public  List<Graph> loadGraph() {
        List<Graph> graphs = new ArrayList<>();

        try (Connection connection = DatabaseConfig.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM BarGraphTable")) {

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String x_axis_label = resultSet.getString("x_axis_label");
                String y_axis_label = resultSet.getString("y_axis_label");
                String categories = resultSet.getString("categories");
                String series = resultSet.getString("series");
                String value = resultSet.getString("value");

                Graph graph = new Graph(id, x_axis_label,y_axis_label,categories,series,value);
                graphs.add(graph);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception in a more appropriate way in a real application
            throw new RuntimeException("Error retrieving all Bar Graphs from the database");
        }
        return graphs;
    }

    public Graph getGraphById(int Id) {
        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM BarGraphTable WHERE id = ?")) {
            statement.setInt(1, Id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String x_axis_label = resultSet.getString("x_axis_label");
                    String y_axis_label = resultSet.getString("y_axis_label");
                    String categories  = resultSet.getString("categories");
                    String series = resultSet.getString("series");
                    String value = resultSet.getString("value");

                    Graph bargraph = new Graph(Id,x_axis_label,y_axis_label,categories,series,value);
                    return bargraph;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception in a more appropriate way in a real application
            throw new RuntimeException("Error retrieving  graph  by id  from the database");
        }
        return null;
    }


    public static List<String> StringToList(String string) {
        String[] stringArray = string.split(",");
        return Arrays.asList(stringArray);
    }

}
