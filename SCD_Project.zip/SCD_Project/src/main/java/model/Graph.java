package model;

//import jdk.internal.loader.Resource;

public class Graph {

    private int id;
    private String x_axis_label;
    private String y_axis_label;
    private String categories ;
    private String series;
    private String value;

    public Graph(int id, String x_axis_label, String y_axis_label, String categories, String series, String value) {
        this.id=id;
        this.x_axis_label=x_axis_label;
        this.y_axis_label=y_axis_label;
        this.categories=categories;
        this.series=series;
        this.value=value;
    }

    public Graph() {}

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getSeries() {
        return series;
    }

    public void setSeries(String series) {
        this.series = series;
    }

    public String getCategories() {
        return categories;
    }

    public void setCategories(String categories) {
        this.categories = categories;
    }

    public String getY_axis_label() {
        return y_axis_label;
    }

    public void setY_axis_label(String y_axis_label) {
        this.y_axis_label = y_axis_label;
    }

    public String getX_axis_label() {
        return x_axis_label;
    }

    public void setX_axis_label(String x_axis_label) {
        this.x_axis_label = x_axis_label;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
