package model;

public class PieChart {
    private String component;
    private String arc_angle;
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public PieChart(int id,String component, String arc_angle) {
        this.component = component;
        this.arc_angle=arc_angle;
        this.id=id;
    }

    public String getArc_angle() {
        return arc_angle;
    }

    public void setArc_angle(String arc_angle) {
        this.arc_angle = arc_angle;
    }

    public PieChart() {
    }

    public String getComponent() {
        return component;
    }

    public void setComponent(String component) {
        this.component = component;
    }
}
