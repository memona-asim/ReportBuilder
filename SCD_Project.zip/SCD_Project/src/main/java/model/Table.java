package model;

import javax.swing.table.DefaultTableModel;

public class Table {
    private String table_name;
    private String[] columnNames;
    private String[][] tableData;



    public Table(String table_name, String[] columnNames) {
        this.table_name = table_name;
        this.columnNames = columnNames;
        this.tableData = new String[0][columnNames.length];
    }

    public Table(){}

    public String[][] getTableData() {
        return tableData;
    }

    public void setTableData(String[][] tableData) {
        this.tableData = tableData;
    }

    public String[] getColumnNames() {
        return columnNames;
    }

    public void setColumnNames(String[] columnNames) {
        this.columnNames = columnNames;
    }

    public String getTable_name() {
        return table_name;
    }

    public void setTable_name(String table_name) {
        this.table_name = table_name;
    }
}
