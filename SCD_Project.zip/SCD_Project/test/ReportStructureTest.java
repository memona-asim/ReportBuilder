//package test;
//
//import Interface.ComponentInfo;
//import Interface.ReportStructure;
//import org.junit.Test;
//
//import java.util.List;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertNotNull;
//
//public class ReportStructureTest {
//
//    @Test
//    public void testConstructor() {
//        ReportStructure reportStructure = new ReportStructure("TestReport", "testFile.txt");
//
//        // Check if the object is not null
//        assertNotNull(reportStructure);
//
//        // Check if the name is set correctly
//        assertEquals("TestReport", reportStructure.getName());
//
//        // Check if the filename is set correctly
//        assertEquals("testFile.txt", reportStructure.getFilename());
//
//        // Check if the componentInfoList is initialized and empty
//        assertNotNull(reportStructure.getComponentInfoList());
//        assertEquals(0, reportStructure.getComponentInfoList().size());
//    }
//
//    @Test
//    public void testAddComponentInfo() {
//        ReportStructure reportStructure = new ReportStructure("TestReport", "testFile.txt");
//        ComponentInfo componentInfo = new ComponentInfo("Type", "Name", 1, 2);
//
//        // Add a componentInfo
//        reportStructure.addComponentInfo(componentInfo);
//
//        // Check if the componentInfoList has one element
//        List<ComponentInfo> componentInfoList = reportStructure.getComponentInfoList();
//        assertNotNull(componentInfoList);
//        assertEquals(1, componentInfoList.size());
//
//        // Check if the added componentInfo is the same as the one added
//        assertEquals(componentInfo, componentInfoList.get(0));
//    }
//}
//
