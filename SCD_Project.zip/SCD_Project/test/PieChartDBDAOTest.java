//package test;
//
//import Buisness.PieChart;
//import org.junit.jupiter.api.*;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//import java.util.HashMap;
//import java.util.List;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//public class PieChartDBDAOTest {
//
//    private static Connection connection;
//
//    @BeforeAll
//    static void setUp() {
//        // Initialize your database connection
//        connection = DatabaseConfig.getConnection();
//    }
//
//    @AfterAll
//    static void tearDown() {
//        // Close the database connection after all tests
//        DatabaseConfig.closeConnection(connection);
//    }
//
//    @BeforeEach
//    void clearDatabase() throws SQLException {
//        // Clean up the database before each test
//        try (PreparedStatement statement = connection.prepareStatement("DELETE FROM PieChartTable")) {
//            statement.executeUpdate();
//        }
//    }
//
//    @Test
//    void testSavePieChartAndLoadPieChart() {
//        PieChart pieChart = createTestPieChart();
//
//        // Save PieChart to the database
//        PieChartDBDAO.savePieChart(pieChart.getData(), pieChart);
//
//        // Load PieChart from the database
//        List<PieChart> loadedPieCharts = PieChartDBDAO.loadPieChart();
//
//        // Assertions
//        assertNotNull(loadedPieCharts);
//        assertEquals(1, loadedPieCharts.size());
//        PieChart loadedPieChart = loadedPieCharts.get(0);
//        assertEquals(pieChart.getId(), loadedPieChart.getId());
//        assertEquals(pieChart.getData(), loadedPieChart.getData());
//    }
//
//    private PieChart createTestPieChart() {
//        PieChart pieChart = new PieChart();
//        pieChart.addDataPoint("Category1", 10);
//        pieChart.addDataPoint("Category2", 20);
//        pieChart.addDataPoint("Category3", 30);
//        return pieChart;
//    }
//}
