//package test;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mockito;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.when;
//
//public class BarGraphStorageTest {
//
//    private BarGraphStorage barGraphStorage;
//    private BarGraphDBDAO barGraphDBDAO;
//
//    @BeforeEach
//    public void setUp() {
//        barGraphDBDAO = Mockito.mock(BarGraphDBDAO.class);
//        barGraphStorage = new BarGraphStorage();
//        barGraphStorage.setBarGraphDBDAO(barGraphDBDAO);
//    }
//
//    @Test
//    public void testLoadBarGraphs() {
//        List<BarGraph> mockBarGraphList = new ArrayList<>();
//        BarGraph mockBarGraph = new BarGraph();
//        mockBarGraph.setId(1);
//        mockBarGraphList.add(mockBarGraph);
//
//        // Mocking the behavior of BarGraphDBDAO.loadFromDB()
//        when(barGraphDBDAO.loadFromDB()).thenReturn(mockBarGraphList);
//
//        barGraphStorage.loadBarGraphs();
//
//        assertEquals(mockBarGraphList, barGraphStorage.getBarGraphList());
//    }
//
//    @Test
//    public void testGetBarGraphList() {
//        List<BarGraph> mockBarGraphList = new ArrayList<>();
//        BarGraph mockBarGraph = new BarGraph();
//        mockBarGraph.setId(1);
//        mockBarGraphList.add(mockBarGraph);
//
//        // Mocking the behavior of BarGraphDBDAO.loadFromDB()
//        when(barGraphDBDAO.loadFromDB()).thenReturn(mockBarGraphList);
//
//        List<BarGraph> result = barGraphStorage.getBarGraphList();
//
//        assertEquals(mockBarGraphList, result);
//    }
//}
