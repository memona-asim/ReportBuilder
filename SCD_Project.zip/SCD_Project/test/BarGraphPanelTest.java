//package test;
//
//import Interface.BarGraphPanel;
//import org.fest.swing.core.GenericTypeMatcher;
//import org.fest.swing.fixture.FrameFixture;
//import org.fest.swing.fixture.JPanelFixture;
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//
//import javax.swing.*;
//import java.awt.event.KeyEvent;
//
//import static org.fest.swing.core.matcher.JButtonMatcher.withText;
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertNotNull;
//
//public class BarGraphPanelTest {
////
//    private FrameFixture window;
//    private BarGraphPanel barGraphPanel;
//
//    @Before
//    public void setUp() {
//        JFrame frame = GuiActionRunner.execute(() -> {
//            JFrame testFrame = new JFrame();
//            barGraphPanel = new BarGraphPanel();
//            testFrame.add(barGraphPanel);
//            testFrame.setSize(800, 600);
//            return testFrame;
//        });
//
//        window = new FrameFixture(frame);
//        window.show(); // shows the frame to test
//    }
//
//    @After
//    public void tearDown() {
//        window.cleanUp();
//    }
//
//    @Test
//    public void testBarGraphPanelInitialization() {
//        JPanelFixture panel = window.panel("barGraphPanel");
//
//        assertNotNull(panel);
//        assertEquals(800, panel.target().getWidth());
//        assertEquals(600, panel.target().getHeight());
//
//        // Add more assertions based on your specific panel state
//    }
//
//    @Test
//    public void testAddBarChartButton() {
//        JButtonFixture addButton = window.button(withText("Add Bar Chart"));
//        addButton.click();
//
//        // Add assertions based on the expected behavior after clicking the button
//    }
//
//    // Add more tests for other functionalities as needed
//
//    // Example test for context menu
//    @Test
//    public void testRightClickContextMenu() {
//        GenericTypeMatcher<JPopupMenu> matcher = new GenericTypeMatcher<>(JPopupMenu.class) {
//            protected boolean isMatching(JPopupMenu popupMenu) {
//                return popupMenu.getComponentCount() == 3; // Assuming there are 3 items in the context menu
//            }
//        };
//
//        JPopupMenuFixture contextMenu = window.panel("barGraphPanel").rightClick().showPopupMenu(matcher);
//
//        // Add assertions for context menu items
//        contextMenu.menuItem("Save").click();
//        // Add more assertions based on the expected behavior
//
//        // Close the context menu
//        contextMenu.pressKey(KeyEvent.VK_ESCAPE);
//    }
//}
//
