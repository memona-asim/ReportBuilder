//package test;
//
//import Buisness.Text;
//import org.junit.jupiter.api.*;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//import java.util.List;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//public class TextDBDAOTest {
//
//    private static Connection connection;
//    private static final String TEST_TEXT = "This is a test text.";
//
//    @BeforeAll
//    static void setUp() {
//        // Initialize your database connection
//        connection = DatabaseConfig.getConnection();
//    }
//
//    @AfterAll
//    static void tearDown() {
//        // Close the database connection after all tests
//        DatabaseConfig.closeConnection(connection);
//    }
//
//    @BeforeEach
//    void clearDatabase() {
//        // Clean up the database before each test
//        dropTableIfExists("TextTable");
//    }
//
//    @Test
//    void testSaveTextAndLoadText() {
//        // Create a test Text object
//        Text testText = new Text(TEST_TEXT);
//
//        // Save the Text to the database
//        TextDBDAO.saveText(testText);
//
//        // Load the Text from the database
//        List<Text> loadedTextList = TextDBDAO.loadText();
//
//        // Assertions
//        assertNotNull(loadedTextList);
//        assertFalse(loadedTextList.isEmpty());
//        assertEquals(1, loadedTextList.size());
//
//        Text loadedText = loadedTextList.get(0);
//        assertEquals(TEST_TEXT, loadedText.getText());
//        assertNotNull(loadedText.getId());
//    }
//
//    @Test
//    void testGetTextById() {
//        // Create a test Text object
//        Text testText = new Text(TEST_TEXT);
//
//        // Save the Text to the database
//        TextDBDAO.saveText(testText);
//
//        // Get the Text by ID from the database
//        Text loadedText = TextDBDAO.getTextById(testText.getId());
//
//        // Assertions
//        assertNotNull(loadedText);
//        assertEquals(testText.getId(), loadedText.getId());
//        assertEquals(TEST_TEXT, loadedText.getText());
//    }
//
//    private void dropTableIfExists(String tableName) {
//        try (PreparedStatement statement = connection.prepareStatement("DROP TABLE IF EXISTS " + tableName)) {
//            statement.executeUpdate();
//        } catch (SQLException e) {
//            throw new RuntimeException(e);
//        }
//    }
//}
