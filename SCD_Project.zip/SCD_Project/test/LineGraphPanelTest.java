//package test;
//
//import Interface.LineGraphPanel;
//import org.junit.Test;
//
//import javax.swing.*;
//
//import static org.junit.Assert.assertNotNull;
//
//public class LineGraphPanelTest {
//
//    @Test
//    public void testAddLineChart() {
//        SwingUtilities.invokeLater(() -> {
//            JFrame frame = new JFrame();
//            LineGraphPanel lineGraphPanel = new LineGraphPanel();
//
//            // Add the LineGraphPanel to the JFrame
//            frame.getContentPane().add(lineGraphPanel);
//
//            // Set the frame size and make it visible
//            frame.setSize(400, 400);
//            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//            frame.setVisible(true);
//
//            // Simulate entering series name, X values, and Y values
//            String seriesName = "Series1";
//            String xValues = "1,2,3,4";
//            String yValues = "10,20,30,40";
//
//            lineGraphPanel.setSeriesComboBox(createComboBox(seriesName));
//
//            // Simulate the input dialog
//            JOptionPane.showInputDialog(lineGraphPanel, "Enter series name:");
//            JOptionPane.showInputDialog(lineGraphPanel, "Enter X values (comma-separated):");
//            JOptionPane.showInputDialog(lineGraphPanel, "Enter Y values (comma-separated):");
//
//            // Set the X and Y values
//            lineGraphPanel.setXValuesTextField(createTextField(xValues));
//            lineGraphPanel.setYValuesTextField(createTextField(yValues));
//
//            // Call the addLineChart method
//            lineGraphPanel.addLineChart();
//
//            // Ensure that the series is added and not null after calling addLineChart
//            assertNotNull(lineGraphPanel.getLineGraph().getSeries(seriesName));
//        });
//    }
//
//    private JComboBox<String> createComboBox(String selectedItem) {
//        String[] items = {selectedItem};
//        return new JComboBox<>(items);
//    }
//
//    private JTextField createTextField(String text) {
//        JTextField textField = new JTextField(text);
//        textField.setColumns(10);
//        return textField;
//    }
//}
