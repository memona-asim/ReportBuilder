//package test;
//
//import org.jfree.chart.ChartColor;
//import org.jfree.chart.JFreeChart;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//
//import java.awt.Color;
//import java.util.HashMap;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//public class BarGraphTest {
//
//    private BarGraph barGraph;
//
//    @BeforeEach
//    public void setUp() {
//        barGraph = new BarGraph();
//    }
//
//    @Test
//    public void testAddData() {
//        barGraph.addData("Series1", "Category1", 10.0);
//        assertEquals(10.0, barGraph.getDataset().getValue("Series1", "Category1"));
//    }
//
//    @Test
//    public void testCreateBarChart() {
//        JFreeChart chart = barGraph.createBarChart("Chart Title", "Category Axis Label", "Value Axis Label");
//        assertNotNull(chart);
//    }
//
//    @Test
//    public void testSetSeriesColor() {
//        barGraph.addData("Series1", "Category1", 10.0);
//        barGraph.createBarChart("Chart Title", "Category Axis Label", "Value Axis Label");
//
//        Color color = Color.RED;
//        barGraph.setSeriesColor("Series1", color);
//
//        CategoryPlot plot = barGraph.getChart().getCategoryPlot();
//        BarRenderer renderer = (BarRenderer) plot.getRenderer();
//        int seriesIndex = barGraph.getDataset().getRowIndex("Series1");
//
//        assertEquals(color, renderer.getSeriesPaint(seriesIndex));
//    }
//
//    @Test
//    public void testGetSeriesNames() {
//        barGraph.addData("Series1", "Category1", 10.0);
//        barGraph.addData("Series2", "Category1", 15.0);
//
//        String[] seriesNames = barGraph.getSeriesNames();
//
//        assertEquals(2, seriesNames.length);
//        assertEquals("Series1", seriesNames[0]);
//        assertEquals("Series2", seriesNames[1]);
//    }
//
//    @Test
//    public void testClearData() {
//        barGraph.addData("Series1", "Category1", 10.0);
//        barGraph.clearData();
//
//        assertEquals(0, barGraph.getDataset().getRowCount());
//    }
//
//    @Test
//    public void testLoadData() {
//        HashMap<String, HashMap<String, Double>> testData = new HashMap<>();
//        HashMap<String, Double> seriesData = new HashMap<>();
//        seriesData.put("Series1", 10.0);
//        testData.put("Category1", seriesData);
//
//        barGraph.loadData(testData);
//
//        assertEquals(10.0, barGraph.getDataset().getValue("Series1", "Category1"));
//    }
//
//    @Test
//    public void testSetAndGetId() {
//        barGraph.setId(123);
//        assertEquals(123, barGraph.getId());
//    }
//
//    @Test
//    public void testSetAndGetAxis() {
//        String[] axis = {"X", "Y", "Z"};
//        barGraph.setAxis(axis);
//
//        assertArrayEquals(axis, barGraph.getAxis());
//    }
//
//    // Additional test for series color using ChartColor
//    @Test
//    public void testSetSeriesColorWithChartColor() {
//        barGraph.addData("Series1", "Category1", 10.0);
//        barGraph.createBarChart("Chart Title", "Category Axis Label", "Value Axis Label");
//
//        Color color = ChartColor.DARK_GREEN;
//        barGraph.setSeriesColor("Series1", color);
//
//        CategoryPlot plot = barGraph.getChart().getCategoryPlot();
//        BarRenderer renderer = (BarRenderer) plot.getRenderer();
//        int seriesIndex = barGraph.getDataset().getRowIndex("Series1");
//
//        assertEquals(color, renderer.getSeriesPaint(seriesIndex));
//    }
//}
//
