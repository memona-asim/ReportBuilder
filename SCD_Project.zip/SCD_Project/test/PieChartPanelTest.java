//package test;
//
//import Interface.ColorChooser;
//import Interface.PieChartPanel;
//import org.junit.Test;
//
//import javax.swing.*;
//import java.awt.*;
//import java.util.HashMap;
//import java.util.Map;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertNotNull;
//
//public class PieChartPanelTest {
//
//    @Test
//    public void testDrawPieChart() {
//        SwingUtilities.invokeLater(() -> {
//            JFrame frame = new JFrame();
//            PieChartPanel pieChartPanel = new PieChartPanel();
//
//            // Add the PieChartPanel to the JFrame
//            frame.getContentPane().add(pieChartPanel);
//
//            // Set the frame size and make it visible
//            frame.setSize(400, 400);
//            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//            frame.setVisible(true);
//
//            // Create a sample dataset
//            Map<String, Integer> pieChartData = new HashMap<>();
//            pieChartData.put("Item1", 30);
//            pieChartData.put("Item2", 40);
//            pieChartData.put("Item3", 30);
//
//            pieChartPanel.setPieChartData(pieChartData);
//            pieChartPanel.drawPieChart();
//
//            // Assert that the PieChartPanel is not null after calling drawPieChart
//            assertNotNull(pieChartPanel);
//
//            // Assert that the keyComboBox is updated
//            JComboBox<String> keyComboBox = pieChartPanel.getKeyComboBox();
//            assertEquals(3, keyComboBox.getItemCount()); // Assuming there are 3 items in the dataset
//
//            // Simulate choosing a key and selecting a color
//            String selectedKey = "Item1";
//            keyComboBox.setSelectedItem(selectedKey);
//
//            // Simulate choosing a color
//            Color color = Color.RED;
//
//            // Call the chooseKeyColor method
//            pieChartPanel.chooseKeyColor();
//
//            // Assert that the colorMap is updated
//            Map<String, Color> colorMap = pieChartPanel.getColorMap();
//            assertEquals(color, colorMap.get(selectedKey));
//        });
//    }
//
//    // Add more test methods for other functionalities as needed
//
//    private class MockColorChooser extends ColorChooser {
//        private Color color;
//
//        @Override
//        public Color chooseColor(Component parent) {
//            return color;
//        }
//
//        public void setColor(Color color) {
//            this.color = color;
//        }
//    }
//}
