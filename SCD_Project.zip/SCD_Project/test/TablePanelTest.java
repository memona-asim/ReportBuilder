//package test;
//
//import Interface.TablePanel;
//import org.junit.Before;
//import org.junit.Test;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertNotNull;
//
//public class TablePanelTest {
//
//    private TablePanel tablePanel;
//
//    @Before
//    public void setUp() {
//        tablePanel = new TablePanel();
//    }
//
//    @Test
//    public void testConstructor() {
//        assertNotNull(tablePanel);
//        assertNotNull(tablePanel.getTableList());
//        assertEquals(0, tablePanel.getTableList().size());
//    }
//
//    @Test
//    public void testToStringArray() {
//        String input = "col1,col2,col3";
//        String[] result = tablePanel.toStringArray(input);
//
//        assertNotNull(result);
//        assertEquals(3, result.length);
//        assertEquals("col1", result[0]);
//        assertEquals("col2", result[1]);
//        assertEquals("col3", result[2]);
//    }
//
//    // You can add more tests for other methods in TablePanel
//
//    @Test
//    public void testSetRows() {
//        tablePanel.setRows(3, 4);
//        assertNotNull(tablePanel.table);
//        assertEquals(3, tablePanel.table.getRows());
//        assertEquals(4, tablePanel.table.getCols());
//    }
//
//    // You can add more tests for the paintComponent method
//
//    @Test
//    public void testLoadFromSaved() {
//        Table savedTable = new Table(2, 2);
//        savedTable.setTableData(0, 0, "A");
//        savedTable.setTableData(1, 1, "B");
//
//        tablePanel.loadFromSaved(savedTable);
//
//        assertNotNull(tablePanel.table);
//        assertEquals(2, tablePanel.table.getRows());
//        assertEquals(2, tablePanel.table.getCols());
//        assertEquals("A", tablePanel.table.getTableData()[0][0]);
//        assertEquals("B", tablePanel.table.getTableData()[1][1]);
//    }
//
//    // You can add more tests for other methods in TablePanel
//}
