//package test;
//
//import DataAccess.TextDBDAO;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//
//public class TextStorageTest {
//
//    @Mock
//    private TextDBDAO textDBDAO;
//
//    @InjectMocks
//    private TextStorage textStorage;
//
//    @BeforeEach
//    public void setUp() {
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    public void testLoadTexts() {
//        List<Text> mockTexts = createMockTexts();
//        when(textDBDAO.loadText()).thenReturn(mockTexts);
//
//        textStorage.loadTexts();
//
//        List<Text> loadedTexts = textStorage.getTextList();
//        assertNotNull(loadedTexts);
//        assertEquals(mockTexts.size(), loadedTexts.size());
//
//        // You can add more specific assertions based on your expected behavior
//    }
//
//    @Test
//    public void testGetTextList() {
//        List<Text> mockTexts = createMockTexts();
//        when(textDBDAO.loadText()).thenReturn(mockTexts);
//
//        List<Text> loadedTexts = textStorage.getTextList();
//        assertNotNull(loadedTexts);
//        assertNotSame(mockTexts, loadedTexts); // Ensure it's a different reference
//        assertEquals(mockTexts.size(), loadedTexts.size());
//
//        // You can add more specific assertions based on your expected behavior
//    }
//
//    private List<Text> createMockTexts() {
//        List<Text> mockTexts = new ArrayList<>();
//        mockTexts.add(createMockText(1, "Text1"));
//        mockTexts.add(createMockText(2, "Text2"));
//        return mockTexts;
//    }
//
//    private Text createMockText(int id, String text) {
//        Text mockText = new Text(id, text);
//        // You can set additional properties if needed
//        return mockText;
//    }
//}
