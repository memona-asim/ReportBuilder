//package test;
//
//import Buisness.LineGraph;
//import org.junit.jupiter.api.*;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//public class LineGraphDBDAOTest {
//
//    private static Connection connection;
//
//    @BeforeAll
//    static void setUp() {
//        // Initialize your database connection
//        connection = DatabaseConfig.getConnection();
//    }
//
//    @AfterAll
//    static void tearDown() {
//        // Close the database connection after all tests
//        DatabaseConfig.closeConnection(connection);
//    }
//
//    @BeforeEach
//    void clearDatabase() throws SQLException {
//        // Clean up the database before each test
//        try (PreparedStatement statement = connection.prepareStatement("DELETE FROM LineGraphTable")) {
//            statement.executeUpdate();
//        }
//    }
//
//    @Test
//    void testSaveToDBAndLoadFromDB() {
//        LineGraph lineGraph = createTestLineGraph();
//
//        // Save LineGraph to the database
//        LineGraphDBDAO.saveToDB(lineGraph);
//
//        // Load LineGraph from the database
//        LineGraph loadedGraph = LineGraphDBDAO.loadFromDB(lineGraph.getId());
//
//        // Assertions
//        assertNotNull(loadedGraph);
//        assertEquals(lineGraph.getId(), loadedGraph.getId());
//        assertEquals(lineGraph.getData(), loadedGraph.getData());
//    }
//
//    private LineGraph createTestLineGraph() {
//        LineGraph lineGraph = new LineGraph();
//        lineGraph.addDataPoint("Series1", 1.0, 2.0);
//        lineGraph.addDataPoint("Series1", 3.0, 4.0);
//        lineGraph.addDataPoint("Series2", 5.0, 6.0);
//        return lineGraph;
//    }
//}
//
