//package test;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//public class TableStorageTest {
//
//    private TableStorage tableStorage;
//
//    @BeforeEach
//    public void setUp() {
//        tableStorage = new TableStorage();
//    }
//
//    @Test
//    public void testLoadList() {
//        List<Table> mockTables = createMockTables();
//        tableStorage.loadList(mockTables);
//
//        List<Table> loadedTables = tableStorage.getTableList();
//        assertNotNull(loadedTables);
//        assertEquals(mockTables.size(), loadedTables.size());
//
//        // You can add more specific assertions based on your expected behavior
//    }
//
//    @Test
//    public void testGetTableList() {
//        List<Table> mockTables = createMockTables();
//        tableStorage.loadList(mockTables);
//
//        List<Table> loadedTables = tableStorage.getTableList();
//        assertNotNull(loadedTables);
//        assertNotSame(mockTables, loadedTables); // Ensure it's a different reference
//        assertEquals(mockTables.size(), loadedTables.size());
//
//        // You can add more specific assertions based on your expected behavior
//    }
//
//    private List<Table> createMockTables() {
//        List<Table> mockTables = new ArrayList<>();
//        mockTables.add(createMockTable("Table1", 3, 4));
//        mockTables.add(createMockTable("Table2", 2, 5));
//        return mockTables;
//    }
//
//    private Table createMockTable(String name, int rows, int cols) {
//        Table mockTable = new Table(rows, cols);
//        mockTable.setName(name);
//        // You can set additional properties if needed
//        return mockTable;
//    }
//}
//
