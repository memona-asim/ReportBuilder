//package test;
//
//import DataAccess.DatabaseConfig;
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//
//import java.sql.Connection;
//import java.sql.SQLException;
//
//import static org.junit.Assert.assertNotNull;
//import static org.junit.Assert.fail;
//
//public class DatabaseConfigTest {
//
//    private Connection connection;
//
//    @Before
//    public void setUp() {
//        // Open a connection before each test
//        connection = DatabaseConfig.getConnection();
//    }
//
//    @After
//    public void tearDown() {
//        // Close the connection after each test
//        DatabaseConfig.closeConnection(connection);
//    }
//
//    @Test
//    public void testGetConnection() {
//        assertNotNull("Connection should not be null", connection);
//        try {
//            // Check if the connection is open
//            if (connection.isClosed()) {
//                fail("Connection should be open");
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            fail("Exception occurred while checking connection status");
//        }
//    }
//
//    @Test
//    public void testCloseConnection() {
//        // Make sure the connection is initially open
//        assertNotNull("Connection should not be null", connection);
//        try {
//            if (connection.isClosed()) {
//                fail("Connection should be open before closing");
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            fail("Exception occurred while checking connection status before closing");
//        }
//
//        // Close the connection
//        DatabaseConfig.closeConnection(connection);
//
//        // Check if the connection is closed after calling closeConnection
//        try {
//            if (!connection.isClosed()) {
//                fail("Connection should be closed after calling closeConnection");
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            fail("Exception occurred while checking connection status after closing");
//        }
//    }
//
//    // Add more tests as needed
//
//}
