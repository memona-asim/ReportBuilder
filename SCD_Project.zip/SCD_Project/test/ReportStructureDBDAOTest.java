//package test;
//
//import org.junit.jupiter.api.*;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.util.HashMap;
//import java.util.Map;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//public class ReportStructureDBDAOTest {
//
//    private static Connection connection;
//
//    @BeforeAll
//    static void setUp() {
//        // Initialize your database connection
//        connection = DatabaseConfig.getConnection();
//    }
//
//    @AfterAll
//    static void tearDown() {
//        // Close the database connection after all tests
//        DatabaseConfig.closeConnection(connection);
//    }
//
//    @BeforeEach
//    void clearDatabase() throws SQLException {
//        // Clean up the database before each test
//        try (PreparedStatement statement = connection.prepareStatement("DELETE FROM report_structure")) {
//            statement.executeUpdate();
//        }
//    }
//
//    @Test
//    void testSaveStructureAndLoadStructure() {
//        // Save structure to the database
//        ReportStructureDBDAO.saveStructure("TestName", "TestFile");
//
//        // Load structure from the database
//        Map<String, String> loadedStructures = ReportStructureDBDAO.loadStructure();
//
//        // Assertions
//        assertNotNull(loadedStructures);
//        assertEquals(1, loadedStructures.size());
//        assertTrue(loadedStructures.containsKey("TestName"));
//        assertEquals("TestFile", loadedStructures.get("TestName"));
//    }
//
//    @Test
//    void testLoadStructureEmpty() {
//        // Load structure from an empty database
//        Map<String, String> loadedStructures = ReportStructureDBDAO.loadStructure();
//
//        // Assertions
//        assertNotNull(loadedStructures);
//        assertTrue(loadedStructures.isEmpty());
//    }
//}
//
