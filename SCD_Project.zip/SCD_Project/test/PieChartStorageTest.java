//package test;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mockito;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.when;
//
//public class PieChartStorageTest {
//
//    private PieChartStorage pieChartStorage;
//    private PieChartDBDAO pieChartDBDAO;
//
//    @BeforeEach
//    public void setUp() {
//        pieChartDBDAO = Mockito.mock(PieChartDBDAO.class);
//        pieChartStorage = new PieChartStorage();
//        pieChartStorage.setPieChartDBDAO(pieChartDBDAO);
//    }
//
//    @Test
//    public void testGetPieChartList() {
//        List<PieChart> mockPieChartList = new ArrayList<>();
//        PieChart mockPieChart = new PieChart();
//        mockPieChartList.add(mockPieChart);
//
//        // Mocking the behavior of PieChartDBDAO.loadPieChart()
//        when(pieChartDBDAO.loadPieChart()).thenReturn(mockPieChartList);
//
//        List<PieChart> result = pieChartStorage.getPieChartList();
//
//        assertEquals(mockPieChartList, result);
//    }
//
//    @Test
//    public void testLoadList() {
//        List<PieChart> mockPieChartList = new ArrayList<>();
//        PieChart mockPieChart = new PieChart();
//        mockPieChartList.add(mockPieChart);
//
//        // Mocking the behavior of PieChartDBDAO.loadPieChart()
//        when(pieChartDBDAO.loadPieChart()).thenReturn(mockPieChartList);
//
//        pieChartStorage.loadList();
//
//        assertEquals(mockPieChartList, pieChartStorage.getPieChartList());
//    }
//}
