//package test;
//
//import DataAccess.BarGraphDBDAO;
//import Buisness.BarGraph;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.HashMap;
//import java.util.List;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//
//public class BarGraphDBDAOTest {
//
//    @Mock
//    private Connection connection;
//
//    @Mock
//    private PreparedStatement preparedStatement;
//
//    @Mock
//    private ResultSet resultSet;
//
//    @InjectMocks
//    private BarGraphDBDAO barGraphDBDAO;
//
//    @BeforeEach
//    public void setUp() {
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    public void testSaveToDB() throws SQLException {
//        BarGraph graph = new BarGraph();
//        graph.setId(1);
//
//        when(connection.prepareStatement(anyString(), anyInt())).thenReturn(preparedStatement);
//        when(preparedStatement.executeUpdate()).thenReturn(1);
//
//        barGraphDBDAO.saveToDB("X Axis", "Y Axis", createMockData(), graph);
//
//        assertEquals(1, graph.getId());
//
//        verify(connection, times(1)).prepareStatement(anyString(), anyInt());
//        verify(preparedStatement, times(1)).executeUpdate();
//    }
//
//    @Test
//    public void testLoadFromDB() throws SQLException {
//        when(connection.createStatement()).thenReturn(preparedStatement);
//        when(preparedStatement.executeQuery(anyString())).thenReturn(resultSet);
//
//        when(resultSet.next()).thenReturn(true).thenReturn(false);
//        when(resultSet.getInt("id")).thenReturn(1);
//        when(resultSet.getString("x_axis_label")).thenReturn("X Axis");
//        when(resultSet.getString("y_axis_label")).thenReturn("Y Axis");
//        when(resultSet.getString("categories")).thenReturn("Category1,Category2");
//        when(resultSet.getString("series")).thenReturn("Series1,Series2");
//        when(resultSet.getString("value")).thenReturn("1.0,2.0");
//
//        List<BarGraph> graphs = barGraphDBDAO.loadFromDB();
//
//        assertNotNull(graphs);
//        assertEquals(1, graphs.size());
//
//        BarGraph loadedGraph = graphs.get(0);
//        assertEquals(1, loadedGraph.getId());
//        assertEquals("X Axis", loadedGraph.getAxis()[0]);
//        assertEquals("Y Axis", loadedGraph.getAxis()[1]);
//
//        HashMap<String, HashMap<String, Double>> loadedData = loadedGraph.getDataset().getData();
//        assertNotNull(loadedData);
//        assertTrue(loadedData.containsKey("Category1"));
//
//        verify(connection, times(1)).createStatement();
//        verify(preparedStatement, times(1)).executeQuery(anyString());
//        verify(resultSet, times(2)).next();
//    }
//
//    private HashMap<String, HashMap<String, Double>> createMockData() {
//        HashMap<String, HashMap<String, Double>> map = new HashMap<>();
//        HashMap<String, Double> innerMap = new HashMap<>();
//        innerMap.put("Series1", 1.0);
//        innerMap.put("Series2", 2.0);
//        map.put("Category1", innerMap);
//        return map;
//    }
//}
//
