//package test;
//
//import Buisness.Text;
//import DataAccess.CsvDAO;
//import DataAccess.TextDBDAO;
//import com.ozten.font.JFontChooser;
//import org.junit.Before;
//import org.junit.Test;
//import org.mockito.Mockito;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.InputEvent;
//import java.awt.event.KeyEvent;
//import java.awt.event.MouseEvent;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertNotNull;
//import static org.mockito.Mockito.*;
//
//public class TextPanelTest {
//
//    private TextPanel textPanel;
//
//    @Before
//    public void setUp() {
//        textPanel = new TextPanel();
//    }
//
//    @Test
//    public void testConstructor() {
//        assertNotNull(textPanel);
//        assertNotNull(textPanel.text);
//        assertEquals(new Point(50, 50), textPanel.textPosition);
//    }
//
//    @Test
//    public void testCreateContextMenu() {
//        JPopupMenu contextMenu = textPanel.createContextMenu();
//        assertNotNull(contextMenu);
//        assertEquals(1, contextMenu.getComponentCount());
//
//        JMenuItem menuItem = contextMenu.getComponent(0);
//        assertEquals("Save", menuItem.getText());
//
//        // Mocking CsvDAO and TextDBDAO for verification
//        CsvDAO csvDAO = Mockito.mock(CsvDAO.class);
//        TextDBDAO textDBDAO = Mockito.mock(TextDBDAO.class);
//        textPanel.saveText(); // Call the method to invoke DAO methods
//        verify(csvDAO, times(1)).saveText(anyString(), any());
//        verify(textDBDAO, times(1)).saveText(any());
//    }
//
//    @Test
//    public void testAddText() {
//        JTextArea mockTextArea = mock(JTextArea.class);
//        JScrollPane mockScrollPane = mock(JScrollPane.class);
//        JFontChooser mockFontChooser = mock(JFontChooser.class);
//        int option = JOptionPane.OK_OPTION;
//
//        when(mockTextArea.getText()).thenReturn("Sample Text");
//        when(mockScrollPane.getViewport()).thenReturn(new JViewport());
//        when(mockFontChooser.showDialog(any(), any(), any())).thenReturn(Font.getFont("Dialog"));
//
//        JOptionPane optionPane = mock(JOptionPane.class);
//        when(optionPane.showOptionDialog(any(), any(), any(), anyInt(), anyInt(), any(), any(), any()))
//                .thenReturn(option);
//
//        textPanel.textArea = mockTextArea;
//        textPanel.scrollPane = mockScrollPane;
//        textPanel.optionPane = optionPane;
//        textPanel.jFontChooser = mockFontChooser;
//
//        textPanel.addText();
//
//        assertEquals("Sample Text", textPanel.text.getText());
//        assertNotNull(textPanel.text.getFont());
//        assertNotNull(textPanel.textPosition);
//        verify(mockTextArea, times(1)).getText();
//        verify(mockFontChooser, times(1)).showDialog(any(), any(), any());
//    }
//
//    @Test
//    public void testLoadText() {
//        CsvDAO mockCsvDAO = mock(CsvDAO.class);
//        TextDBDAO mockTextDBDAO = mock(TextDBDAO.class);
//
//        // Stubbing CsvDAO
//        when(mockCsvDAO.loadText()).thenReturn("Loaded Text");
//
//        // Stubbing the FontChooser
//        JFontChooser mockFontChooser = mock(JFontChooser.class);
//        when(mockFontChooser.showDialog(any(), any(), any())).thenReturn(Font.getFont("Dialog"));
//
//        // Injecting the mocks
//        textPanel.csvDAO = mockCsvDAO;
//        textPanel.textDBDAO = mockTextDBDAO;
//        textPanel.jFontChooser = mockFontChooser;
//
//        textPanel.loadText();
//
//        assertEquals("Loaded Text", textPanel.text.getText());
//        assertNotNull(textPanel.text.getFont());
//        assertNotNull(textPanel.textPosition);
//        verify(mockCsvDAO, times(1)).loadText();
//        verify(mockFontChooser, times(1)).showDialog(any(), any(), any());
//    }
//
//    @Test
//    public void testLoadFromSaved() {
//        Text savedText = new Text();
//        savedText.setText("Saved Text");
//
//        JFontChooser mockFontChooser = mock(JFontChooser.class);
//        when(mockFontChooser.showDialog(any(), any(), any())).thenReturn(Font.getFont("Dialog"));
//
//        textPanel.jFontChooser = mockFontChooser;
//
//        textPanel.loadFromSaved(savedText);
//
//        assertEquals("Saved Text", textPanel.text.getText());
//        assertNotNull(textPanel.text.getFont());
//        assertNotNull(textPanel.textPosition);
//        verify(mockFontChooser, times(1)).showDialog(any(), any(), any());
//    }
//
//    @Test
//    public void testPaintComponent() {
//        // Implement this test based on the logic in paintComponent
//        // It involves dealing with FontMetrics and rendering text.
//        // Since this method uses a lot of graphic functions, it is more suited for manual testing.
//
//        // You might consider using a testing library like FEST-Swing to simulate GUI interactions and verify visual results.
//    }
//
//    // Add more tests as needed
//
//}
