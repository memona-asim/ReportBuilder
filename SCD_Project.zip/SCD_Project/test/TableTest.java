//package test;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import static org.junit.jupiter.api.Assertions.*;
//
//public class TableTest {
//
//    private Table table;
//
//    @BeforeEach
//    public void setUp() {
//        int rows = 3;
//        int cols = 4;
//        table = new Table(rows, cols);
//    }
//
//    @Test
//    public void testSetAndGetColNames() {
//        String[] colNames = {"Column1", "Column2", "Column3", "Column4"};
//        table.setColNames(colNames);
//
//        assertArrayEquals(colNames, table.getColNames());
//    }
//
//    @Test
//    public void testSetName() {
//        String tableName = "TestTable";
//        table.setName(tableName);
//
//        assertEquals(tableName, table.getName());
//    }
//
//    @Test
//    public void testGetRows() {
//        assertEquals(3, table.getRows());
//    }
//
//    @Test
//    public void testGetCols() {
//        assertEquals(4, table.getCols());
//    }
//
//    @Test
//    public void testSetRows() {
//        int newRowCount = 5;
//        table.setRows(newRowCount);
//
//        assertEquals(newRowCount, table.getRows());
//    }
//
//    @Test
//    public void testSetCols() {
//        int newColCount = 6;
//        table.setCols(newColCount);
//
//        assertEquals(newColCount, table.getCols());
//    }
//
//    @Test
//    public void testSetAndGetTableData() {
//        String[][] testData = {
//                {"1", "A", "X", "10.5"},
//                {"2", "B", "Y", "20.7"},
//                {"3", "C", "Z", "30.2"}
//        };
//
//        table.setDataSet(testData);
//
//        assertArrayEquals(testData, table.getTableData());
//
//        // Modify a value in the table data
//        table.setTableData(1, 2, "Modified");
//        assertEquals("Modified", table.getTableData()[1][2]);
//    }
//}
