//package test;
//
//import Buisness.LineGraph;
//import DataAccess.CsvDAO;
//import Interface.*;
//import org.junit.jupiter.api.Test;
//
//import javax.swing.*;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import static org.mockito.Mockito.mock;
//
//public class CsvDAOTest {
//
//    @Test
//    public void testLoadText() {
//        CsvDAO csvDAO = new CsvDAO();
//
//        // Mocking JFileChooser to simulate user selecting a file
//        JFileChooser fileChooser = mock(JFileChooser.class);
//        csvDAO.loadText();
//
//        // Add your assertions here
//    }
//
//    @Test
//    public void testSaveText() {
//        CsvDAO csvDAO = new CsvDAO();
//        TextPanel textPanel = mock(TextPanel.class);
//
//        // Add your assertions here
//    }
//
//    @Test
//    public void testLoadTableData() {
//        CsvDAO csvDAO = new CsvDAO();
//
//        // Mocking JFileChooser to simulate user selecting a file
//        JFileChooser fileChooser = mock(JFileChooser.class);
//        int[] arr = new int[2];
//        String[][] data = csvDAO.loadTableData(arr);
//
//        // Add your assertions here
//    }
//
//    @Test
//    public void testSaveTableData() {
//        CsvDAO csvDAO = new CsvDAO();
//        TablePanel tablePanel = mock(TablePanel.class);
//        String[][] data = {{"1", "2"}, {"3", "4"}};
//
//        // Add your assertions here
//    }
//
//    @Test
//    public void testLoadPieChart() {
//        CsvDAO csvDAO = new CsvDAO();
//
//        // Mocking JFileChooser to simulate user selecting a file
//        JFileChooser fileChooser = mock(JFileChooser.class);
//        HashMap<String, Integer> pieChartData = csvDAO.loadPieChart();
//
//        // Add your assertions here
//    }
//
//    @Test
//    public void testSavePieChartData() {
//        CsvDAO csvDAO = new CsvDAO();
//        PieChartPanel pieChartPanel = mock(PieChartPanel.class);
//        HashMap<String, Integer> pieChartData = new HashMap<>();
//        pieChartData.put("Category1", 10);
//        pieChartData.put("Category2", 20);
//
//        // Add your assertions here
//    }
//
//    @Test
//    public void testSaveBarChartData() {
//        CsvDAO csvDAO = new CsvDAO();
//        BarGraphPanel barGraphPanel = mock(BarGraphPanel.class);
//        HashMap<String, HashMap<String, Double>> barGraphData = new HashMap<>();
//        barGraphData.put("Category1", new HashMap<>());
//        barGraphData.get("Category1").put("Series1", 10.0);
//        barGraphData.get("Category1").put("Series2", 20.0);
//
//        // Add your assertions here
//    }
//
//    @Test
//    public void testLoadBarChartData() {
//        CsvDAO csvDAO = new CsvDAO();
//        String[] array = new String[3];
//        HashMap<String, HashMap<String, Double>> barGraphData = csvDAO.loadBarChartData(array);
//
//        // Add your assertions here
//    }
//
//    @Test
//    public void testSaveLineGraphData() {
//        CsvDAO csvDAO = new CsvDAO();
//        LineGraphPanel lineGraphPanel = mock(LineGraphPanel.class);
//        LineGraph lineGraph = new LineGraph();
//
//        // Assuming LineGraph has a method getData()
//        // Add your assertions here
//    }
//
//    @Test
//    public void testLoadLineGraphData() {
//        CsvDAO csvDAO = new CsvDAO();
//        Map<String, List<double[]>> lineGraphData = csvDAO.loadLineGraphData();
//
//        // Add your assertions here
//    }
//}
//
