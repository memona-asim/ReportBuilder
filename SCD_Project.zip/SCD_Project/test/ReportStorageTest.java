//package test;
//
//import DataAccess.ReportStructureDBDAO;
//import Interface.ReportStructure;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//
//import java.io.IOException;
//import java.io.ObjectInputStream;
//import java.util.HashMap;
//import java.util.List;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//
//public class ReportStorageTest {
//
//    @Mock
//    private ReportStructureDBDAO reportStructureDBDAO;
//
//    private ReportStorage reportStorage;
//
//    @BeforeEach
//    public void setUp() {
//        MockitoAnnotations.openMocks(this);
//        reportStorage = new ReportStorage();
//        reportStorage.setReportStructureDBDAO(reportStructureDBDAO);
//    }
//
//    @Test
//    public void testLoadReports() {
//        // Mocking the behavior of ReportStructureDBDAO.loadStructure()
//        HashMap<String, String> mockMap = new HashMap<>();
//        mockMap.put("Report1", "path/to/Report1.ser");
//        mockMap.put("Report2", "path/to/Report2.ser");
//
//        when(reportStructureDBDAO.loadStructure()).thenReturn(mockMap);
//
//        reportStorage.loadReports();
//
//        List<ReportStructure> reports = reportStorage.getReports();
//        assertNotNull(reports);
//        assertEquals(2, reports.size());
//        // You can add more assertions based on your expected behavior
//    }
//
//    @Test
//    public void testLoadReportStructure() throws IOException, ClassNotFoundException {
//        // Create a temporary file for testing
//        String tempFilePath = "path/to/tempReport.ser";
//        ReportStructure expectedReport = new MockReportStructure("TestReport", tempFilePath);
//
//        // Mocking the behavior of ObjectInputStream
//        try (MockedObjectInputStream ois = new MockedObjectInputStream(tempFilePath)) {
//            when(reportStructureDBDAO.loadStructure("TestReport")).thenReturn(tempFilePath);
//            ReportStructure loadedReport = reportStorage.loadReportStructure("TestReport");
//            assertEquals(expectedReport.getName(), loadedReport.getName());
//            assertEquals(expectedReport.getFilename(), loadedReport.getFilename());
//        }
//    }
//
//    @Test
//    public void testSaveToDB() {
//        ReportStructure mockReport = new MockReportStructure("MockReport", "path/to/MockReport.ser");
//
//        reportStorage.savetoDB(mockReport);
//
//        // Verify that the ReportStructureDBDAO.saveStructure() was called with the correct arguments
//        verify(reportStructureDBDAO, times(1)).saveStructure("MockReport", "path/to/MockReport.ser");
//    }
//
//    // Mock implementation of ObjectInputStream to simulate reading an object from a file
//    private static class MockedObjectInputStream extends ObjectInputStream {
//
//        private String filePath;
//
//        public MockedObjectInputStream(String filePath) throws IOException {
//            super(new FileInputStream(filePath));
//            this.filePath = filePath;
//        }
//
//        @Override
//        public Object readObject() throws IOException, ClassNotFoundException {
//            // Return a mock ReportStructure object
//            return new MockReportStructure("MockReport", filePath);
//        }
//    }
//
//    // Mock implementation of ReportStructure for testing purposes
//    private static class MockReportStructure implements ReportStructure {
//
//        private String name;
//        private String filename;
//
//        public MockReportStructure(String name, String filename) {
//            this.name = name;
//            this.filename = filename;
//        }
//
//        @Override
//        public String getName() {
//            return name;
//        }
//
//        @Override
//        public String getFilename() {
//            return filename;
//        }
//    }
//}
//
