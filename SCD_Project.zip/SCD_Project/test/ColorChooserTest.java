//package test;
//
//import org.junit.Test;
//import org.mockito.ArgumentCaptor;
//
//import javax.swing.*;
//import java.awt.*;
//
//import static org.junit.Assert.assertEquals;
//import static org.mockito.Mockito.*;
//
//public class ColorChooserTest {
//
//    @Test
//    public void testChooseColor() {
//        // Mock the JColorChooser
//        JColorChooser mockColorChooser = mock(JColorChooser.class);
//        Color expectedColor = Color.RED;
//
//        // Set up the JColorChooser to return the expectedColor
//        when(mockColorChooser.showDialog(any(Component.class), anyString(), any(Color.class)))
//                .thenReturn(expectedColor);
//
//        // Use ArgumentCaptor to capture the arguments passed to the JColorChooser
//        ArgumentCaptor<Component> componentCaptor = ArgumentCaptor.forClass(Component.class);
//        ArgumentCaptor<String> titleCaptor = ArgumentCaptor.forClass(String.class);
//        ArgumentCaptor<Color> initialColorCaptor = ArgumentCaptor.forClass(Color.class);
//
//        // Call the method to be tested
//        Color chosenColor = ColorChooser.chooseColor(mockColorChooser);
//
//        // Verify that the JColorChooser.showDialog was called with the correct arguments
//        verify(mockColorChooser).showDialog(
//                componentCaptor.capture(),
//                titleCaptor.capture(),
//                initialColorCaptor.capture()
//        );
//
//        // Assert that the arguments passed to JColorChooser.showDialog are as expected
//        assertEquals("Choose a Color", titleCaptor.getValue());
//        assertEquals(Color.BLACK, initialColorCaptor.getValue()); // Default color
//
//        // Assert that the method returns the expectedColor
//        assertEquals(expectedColor, chosenColor);
//    }
//}
//
