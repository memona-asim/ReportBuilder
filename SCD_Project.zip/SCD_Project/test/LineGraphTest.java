//package test;
//
//import org.jfree.chart.JFreeChart;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mockito;
//
//import java.awt.Color;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.when;
//
//public class LineGraphTest {
//
//    private LineGraph lineGraph;
//    private LineGraphDBDAO lineGraphDBDAO;
//
//    @BeforeEach
//    public void setUp() {
//        lineGraphDBDAO = Mockito.mock(LineGraphDBDAO.class);
//        lineGraph = new LineGraph();
//        lineGraph.setLineGraphDBDAO(lineGraphDBDAO);
//    }
//
//    @Test
//    public void testAddSeries() {
//        lineGraph.addSeries("Series1");
//        List<String> seriesNames = lineGraph.getSeriesNames();
//        assertEquals(1, seriesNames.size());
//        assertEquals("Series1", seriesNames.get(0));
//    }
//
//    @Test
//    public void testAddDataPoint() {
//        lineGraph.addSeries("Series1");
//        lineGraph.addDataPoint("Series1", 1.0, 2.0);
//
//        Map<String, List<double[]>> dataMap = lineGraph.getData();
//        List<double[]> seriesData = dataMap.get("Series1");
//
//        assertNotNull(seriesData);
//        assertEquals(1, seriesData.size());
//        assertEquals(1.0, seriesData.get(0)[0]);
//        assertEquals(2.0, seriesData.get(0)[1]);
//    }
//
//    @Test
//    public void testCreateLineChart() {
//        JFreeChart chart = lineGraph.createLineChart("Chart Title", "X Axis", "Y Axis");
//        assertNotNull(chart);
//    }
//
//    @Test
//    public void testSetSeriesColor() {
//        lineGraph.addSeries("Series1");
//        lineGraph.createLineChart("Chart Title", "X Axis", "Y Axis");
//
//        Color color = Color.BLUE;
//        lineGraph.setSeriesColor("Series1", color);
//
//        XYItemRenderer renderer = lineGraph.getChart().getXYPlot().getRenderer();
//        int seriesIndex = lineGraph.getDataset().indexOf("Series1");
//
//        assertEquals(color, renderer.getSeriesPaint(seriesIndex));
//    }
//
//    @Test
//    public void testLoadData() {
//        Map<String, List<double[]>> testData = new HashMap<>();
//        List<double[]> seriesData = new ArrayList<>();
//        seriesData.add(new double[]{1.0, 2.0});
//        testData.put("Series1", seriesData);
//
//        lineGraph.loadData(testData);
//
//        assertEquals(1.0, lineGraph.getData().get("Series1").get(0)[0]);
//        assertEquals(2.0, lineGraph.getData().get("Series1").get(0)[1]);
//    }
//
//    @Test
//    public void testSaveToDB() {
//        // Mocking the behavior of LineGraphDBDAO.saveToDB()
//        when(lineGraphDBDAO.saveToDB(lineGraph)).thenReturn(true);
//
//        assertTrue(lineGraph.saveToDB());
//    }
//
//    @Test
//    public void testLoadFromDB() {
//        int graphId = 1;
//        LineGraph mockLineGraph = new LineGraph();
//        mockLineGraph.setId(graphId);
//
//        // Mocking the behavior of LineGraphDBDAO.loadFromDB()
//        when(lineGraphDBDAO.loadFromDB(graphId)).thenReturn(mockLineGraph);
//
//        LineGraph loadedGraph = LineGraph.loadFromDB(graphId);
//
//        assertNotNull(loadedGraph);
//        assertEquals(graphId, loadedGraph.getId());
//    }
//}
//
