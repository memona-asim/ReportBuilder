//package test;
//
//import Interface.ImagePanel;
//import org.junit.Test;
//
//import javax.swing.*;
//import java.awt.*;
//import java.io.File;
//
//import static org.junit.Assert.assertNotNull;
//
//public class ImagePanelTest {
//
//    @Test
//    public void testAddImage() {
//        SwingUtilities.invokeLater(() -> {
//            JFrame frame = new JFrame();
//            ImagePanel imagePanel = new ImagePanel();
//
//            // Add the ImagePanel to the JFrame
//            frame.getContentPane().add(imagePanel);
//
//            // Set the frame size and make it visible
//            frame.setSize(400, 400);
//            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//            frame.setVisible(true);
//
//            // Simulate selecting an image file
//            File imageFile = new File("path/to/your/image.jpg");
//
//            // Simulate the JFileChooser
//            JFileChooser fileChooser = new JFileChooser() {
//                @Override
//                public int showOpenDialog(Component parent) {
//                    imagePanel.setImageFromFile(imageFile);
//                    return JFileChooser.APPROVE_OPTION;
//                }
//            };
//
//            // Call the addImage method
//            imagePanel.addImage(fileChooser);
//
//            // Ensure that the image is not null after calling addImage
//            assertNotNull(imagePanel.getImage());
//        });
//    }
//}
//
