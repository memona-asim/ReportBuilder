//package test;
//
//import Interface.PieChartPanel;
//import Interface.Report;
//import org.assertj.swing.core.GenericTypeMatcher;
//import org.assertj.swing.fixture.FrameFixture;
//import org.assertj.swing.junit.testcase.AssertJSwingJUnitTestCase;
//import org.junit.Test;
//
//import javax.swing.*;
//
//public class ReportTest extends AssertJSwingJUnitTestCase {
//
//    private FrameFixture window;
//
//    @Override
//    protected void onSetUp() {
//        Report report = GuiActionRunner.execute(() -> new Report());
//        window = new FrameFixture(robot(), report);
//        window.show();
//    }
//
//    @Test
//    public void testAddPieChart() {
//        // Simulate a button click to add a Pie Chart
//        window.button("Pie Chart").click();
//
//        // Perform assertions based on the expected behavior
//        window.panel("contentPanel").requireComponent(new GenericTypeMatcher<JPanel>(JPanel.class) {
//            protected boolean isMatching(JPanel panel) {
//                // Customize the matcher based on your component structure
//                return panel.getComponentCount() == 1 && panel.getComponent(0) instanceof PieChartPanel;
//            }
//        });
//    }
//
//    @Test
//    public void testSaveReportStructure() {
//        // Simulate the process of saving the report structure
//        window.menuItem("File").click();
//        window.menuItem("Save Structure").click();
//
//        // Handle dialog interactions if any, and assert the results
//        // (Note: This part may vary based on the actual dialog implementation)
//        window.dialog().textBox().enterText("TestReport");
//        window.dialog().button("OK").click();
//
//        // Perform assertions based on the expected behavior
//        // You might want to check if the report structure is saved correctly in your model
//        // and possibly verify the updated UI state.
//    }
//
//    // Add more tests for other functionalities following a similar structure
//
//    @Override
//    protected void onTearDown() {
//        // Clean up resources if needed
//        window.cleanUp();
//    }
//}
//
