//package test;
//
//import org.jfree.chart.JFreeChart;
//import org.jfree.chart.plot.PiePlot;
//import org.jfree.data.general.DefaultPieDataset;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//
//import java.util.HashMap;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//public class PieChartTest {
//
//    private PieChart pieChart;
//
//    @BeforeEach
//    public void setUp() {
//        pieChart = new PieChart();
//    }
//
//    @Test
//    public void testAddData() {
//        HashMap<String, Integer> testData = new HashMap<>();
//        testData.put("Category1", 10);
//        pieChart.addData(testData);
//
//        assertEquals(testData, pieChart.getDataSet());
//    }
//
//    @Test
//    public void testShowPie() {
//        HashMap<String, Integer> testData = new HashMap<>();
//        testData.put("Category1", 10);
//        pieChart.addData(testData);
//
//        JFreeChart chart = pieChart.showPie();
//        assertNotNull(chart);
//
//        // Ensure the chart has a PiePlot
//        assertTrue(chart.getPlot() instanceof PiePlot);
//        PiePlot plot = (PiePlot) chart.getPlot();
//
//        // Check if the dataset in the chart matches the added data
//        DefaultPieDataset chartDataset = (DefaultPieDataset) plot.getDataset();
//        assertEquals(testData.size(), chartDataset.getItemCount());
//
//        for (String category : testData.keySet()) {
//            assertEquals(testData.get(category), chartDataset.getValue(category));
//        }
//    }
//
//    @Test
//    public void testSetAndGetId() {
//        pieChart.setId(123);
//        assertEquals(123, pieChart.getId());
//    }
//
//    @Test
//    public void testDefaultConstructor() {
//        PieChart emptyPieChart = new PieChart();
//        assertNotNull(emptyPieChart);
//        assertNull(emptyPieChart.getDataSet());
//    }
//}
//
