//package test;
//
//import org.junit.Test;
//import static org.junit.Assert.*;
//
//public class ComponentInfoTest {
//
//    @Test
//    public void testGetters() {
//        // Arrange
//        String componentType = "Button";
//        String componentName = "submitButton";
//        int gridRow = 2;
//        int gridColumn = 3;
//
//        // Act
//        ComponentInfo componentInfo = new ComponentInfo(componentType, componentName, gridRow, gridColumn);
//
//        // Assert
//        assertEquals(componentType, componentInfo.getComponentType());
//        assertEquals(componentName, componentInfo.getComponentName());
//        assertEquals(gridRow, componentInfo.getGridRow());
//        assertEquals(gridColumn, componentInfo.getGridColumn());
//    }
//
//    @Test
//    public void testEquality() {
//        // Arrange
//        ComponentInfo componentInfo1 = new ComponentInfo("Button", "submitBtn", 1, 1);
//        ComponentInfo componentInfo2 = new ComponentInfo("Button", "submitBtn", 1, 1);
//        ComponentInfo componentInfo3 = new ComponentInfo("TextField", "usernameField", 2, 2);
//
//        // Assert
//        assertEquals(componentInfo1, componentInfo2);
//        assertNotEquals(componentInfo1, componentInfo3);
//    }
//}
