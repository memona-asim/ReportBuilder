//package test;
//
//import Buisness.Table;
//import org.junit.jupiter.api.*;
//
//import java.sql.*;
//import java.util.Arrays;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//public class TableDBDAOTest {
//
//    private static Connection connection;
//    private static final String TEST_TABLE_NAME = "test_table";
//
//    @BeforeAll
//    static void setUp() {
//        // Initialize your database connection
//        connection = DatabaseConfig.getConnection();
//    }
//
//    @AfterAll
//    static void tearDown() {
//        // Close the database connection after all tests
//        DatabaseConfig.closeConnection(connection);
//    }
//
//    @BeforeEach
//    void clearDatabase() {
//        // Clean up the database before each test
//        dropTableIfExists(TEST_TABLE_NAME);
//    }
//
//    @Test
//    void testSaveTableAndLoadTable() {
//        // Create a test table
//        Table testTable = new Table(2, 3);
//        String[] columnNames = {"ID", "Name", "Age"};
//        testTable.setColNames(columnNames);
//        String[][] tableData = {{"1", "John", "25"}, {"2", "Jane", "30"}};
//        testTable.setDataSet(tableData);
//
//        // Save the table to the database
//        TableDBDAO.saveTable(testTable);
//
//        // Load the table from the database
//        Table loadedTable = TableDBDAO.loadTable(TEST_TABLE_NAME);
//
//        // Assertions
//        assertNotNull(loadedTable);
//        assertArrayEquals(columnNames, loadedTable.getColNames());
//        assertArrayEquals(tableData, loadedTable.getTableData());
//    }
//
//    private void dropTableIfExists(String tableName) {
//        try (Statement statement = connection.createStatement()) {
//            statement.executeUpdate("DROP TABLE IF EXISTS " + tableName);
//        } catch (SQLException e) {
//            throw new RuntimeException(e);
//        }
//    }
//}
//
