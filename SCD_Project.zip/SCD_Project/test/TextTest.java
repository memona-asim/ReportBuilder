//package test;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//
//import java.awt.*;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//public class TextTest {
//
//    private Text text;
//
//    @BeforeEach
//    public void setUp() {
//        text = new Text(1, "Sample Text");
//    }
//
//    @Test
//    public void testSetAndGetId() {
//        int newId = 2;
//        text.setId(newId);
//
//        assertEquals(newId, text.getId());
//    }
//
//    @Test
//    public void testSetText() {
//        String newText = "Updated Text";
//        text.setText(newText);
//
//        assertEquals(newText, text.getText());
//    }
//
//    @Test
//    public void testSetAndGetFont() {
//        Font newFont = new Font("Arial", Font.BOLD, 16);
//        text.setFont(newFont);
//
//        assertEquals(newFont, text.getFont());
//    }
//
//    @Test
//    public void testDefaultConstructor() {
//        Text defaultText = new Text();
//
//        // Ensure default values are set
//        assertEquals(0, defaultText.getId());
//        assertNull(defaultText.getText());
//        assertNull(defaultText.getFont());
//    }
//
//    @Test
//    public void testParameterizedConstructor() {
//        Text parameterizedText = new Text(3, "Hello");
//
//        // Ensure values are set through the constructor
//        assertEquals(3, parameterizedText.getId());
//        assertEquals("Hello", parameterizedText.getText());
//        assertNull(parameterizedText.getFont()); // Font is not set in the constructor
//    }
//}
//
