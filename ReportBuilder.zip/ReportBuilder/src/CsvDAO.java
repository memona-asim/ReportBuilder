import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class CsvDAO {
    public void loadText() {
    }
    public void saveText(String s, Report report){
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showSaveDialog(report);
        if (result == JFileChooser.APPROVE_OPTION) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileChooser.getSelectedFile()))) {
                writer.write(s);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
    public void loadTable(){

    }
    public void saveTable(){

    }
    public static ArrayList<Integer> loadPieChart() {
        ArrayList<Integer> integerList = null;

        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(null);

        if (result == JFileChooser.APPROVE_OPTION) {
            try (BufferedReader reader = new BufferedReader(new FileReader(fileChooser.getSelectedFile()))) {
                String line = reader.readLine();
                if (line != null) {
                    // Split the line into an array of strings using a comma as a delimiter
                    String[] stringNumbers = line.split(",");

                    // Create an ArrayList to store integers
                    integerList = new ArrayList<>();

                    // Convert each string element to an integer and add it to the ArrayList
                    for (String str : stringNumbers) {
                        int number = Integer.parseInt(str.trim());
                        integerList.add(number);
                    }
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        return integerList;
    }
    public static void savePieChartData(ArrayList<Integer> pieChartData, Report report) {
        if (pieChartData == null || pieChartData.isEmpty()) {
            JOptionPane.showMessageDialog(report, "No pie chart data to save.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showSaveDialog(report);

        if (result == JFileChooser.APPROVE_OPTION) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileChooser.getSelectedFile()))) {
                for (int value : pieChartData) {
                    writer.write(value + ",");
                }
                System.out.println("Pie chart data saved successfully.");
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(report, "Error saving pie chart data.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    public void loadBarChart(){

    }
    public void saveBarChart(){

    }
    public void loadLineChart(){

    }
    public void saveLineChart(){

    }
}
