import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class Report extends JFrame {

    private JPanel chartPanel;
    private ArrayList<Integer> pieChartData;

    public Report() {
        setTitle("Report Builder");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        chartPanel = new JPanel();
        chartPanel.setLayout(new BorderLayout());
        chartPanel.setBackground(Color.WHITE);

        JButton pieChartButton = new JButton("Add Pie Chart");
        pieChartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String dataset = JOptionPane.showInputDialog("Enter Pie Chart dataset (comma-separated values):");
                if (dataset != null && !dataset.isEmpty()) {
                    pieChartData=(parseDataset(dataset));
                    drawPieChart();
                }
            }
        });
        JButton loadPieChartButton = new JButton("load Pie Chart");
        loadPieChartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //String filename = JOptionPane.showInputDialog("Enter the name of the file. (e.g. filename.csv)):");
                ArrayList<Integer> data=CsvDAO.loadPieChart();
                for(int i: data){
                    pieChartData=data;
                    drawPieChart();
                }
            }
        });

        JButton saveButton = new JButton("Save Pie Chart Data");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CsvDAO.savePieChartData(pieChartData, Report.this);
            }
        });

        JPanel controlPanel = new JPanel();
        controlPanel.add(pieChartButton);
        controlPanel.add(saveButton);
        controlPanel.add(loadPieChartButton);

        add(controlPanel, BorderLayout.NORTH);
        add(chartPanel, BorderLayout.CENTER);
    }

    private ArrayList<Integer> parseDataset(String dataset) {
        String[] values = dataset.split(",");
        ArrayList<Integer> data = null;
        for (String value : values) {
            assert false;
            data.add(Integer.parseInt(value.trim()));
        }
        return data;
    }

    private void drawPieChart() {
        System.out.println("Drawing Pie Chart");
        chartPanel.removeAll();
        chartPanel.add(new PieChart(pieChartData), BorderLayout.CENTER);
        chartPanel.revalidate();
        chartPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Report().setVisible(true);
            }
        });
    }
}