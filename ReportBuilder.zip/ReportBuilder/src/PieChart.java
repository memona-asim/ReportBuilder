import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

class PieChart extends JPanel {

    private ArrayList<Integer> data;

    public PieChart(ArrayList<Integer> data) {
        this.data = data;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int width = getWidth();
        int height = getHeight();
        int cx = width / 2;
        int cy = height / 2;
        int radius = Math.min(width, height) / 2 - 10;

        int total = 0;
        for (int value : data) {
            total += value;
        }

        int startAngle = 0;
        for (Integer datum : data) {
            int arcAngle = (int) Math.round((360.0 * datum) / total);

            g.setColor(getRandomColor());
            g.fillArc(cx - radius, cy - radius, 2 * radius, 2 * radius, startAngle, arcAngle);

            startAngle += arcAngle;
        }
    }

    private Color getRandomColor() {
        int r = (int) (Math.random() * 256);
        int g = (int) (Math.random() * 256);
        int b = (int) (Math.random() * 256);
        return new Color(r, g, b);
    }
}
